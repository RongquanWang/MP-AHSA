from Algorithm import main
import random
from collections import defaultdict
import math
import string
from Metrics import Measure
from numpy.matlib import zeros


# ****************************************************************
def Read_interactionfile(filename):
    relations = defaultdict(list)
    label_id = {}
    id_label = {}
    total = 0
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        # print "start_name =",start_name
        end_name = line_interaction[1].strip();
        # print "end_name =",end_name
        # weightid = line_interaction[2].strip();
        if start_name not in label_id:
            label_id[start_name] = len(label_id);
            id_label[len(id_label)] = start_name
        if end_name not in label_id:
            label_id[end_name] = len(label_id);
            id_label[len(id_label)] = end_name
        if ((not label_id[start_name] in relations[label_id[end_name]]) and start_name != end_name):
            total = total + 1
            relations[label_id[end_name]].append(label_id[start_name]);
            relations[label_id[start_name]].append(label_id[end_name]);
    print("Total number of interactions(duplications are removed):", total)
    print("Total number of proteins:", len(label_id))

    N = len(label_id)
    weight = zeros((N, N))
    num = 1
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        end_name = line_interaction[1].strip();
        weightid2 = line_interaction[2].strip();
        weightid3 = line_interaction[3].strip();
        weightid4 = line_interaction[4].strip();
        weightid = (float(weightid2)+float(weightid3)+float(weightid4))/3
        #print "start_name,end_name,weight =", start_name,end_name,weightid,num
        num = num + 1
        weight[label_id[start_name], label_id[end_name]] = weightid
        weight[label_id[end_name], label_id[start_name]] = weightid
    return relations, label_id, id_label, weight
# ****************************************************************
def Read_interactionfile1(filename):
    relations = defaultdict(list)
    label_id = {}
    id_label = {}
    total = 0
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        # print "start_name =",start_name
        end_name = line_interaction[1].strip();
        # print "end_name =",end_name
        if start_name not in label_id:
            label_id[start_name] = len(label_id);
            id_label[len(id_label)] = start_name
        if end_name not in label_id:
            label_id[end_name] = len(label_id);
            id_label[len(id_label)] = end_name
        if ((not label_id[start_name] in relations[label_id[end_name]]) and start_name != end_name):
            total = total + 1
            relations[label_id[end_name]].append(label_id[start_name]);
            relations[label_id[start_name]].append(label_id[end_name]);
    print("Total number of interactions(duplications are removed):", total)
    print("Total number of proteins:", len(label_id))
    return relations, label_id, id_label
# ****************************************************************
def CreateResultFile(seedt,id_protein,f ="Result.txt"):
    f = open(f,'w')
    k = 0
    for id in seedt:
        lists = seedt[id]
        if len(lists) < 3:
            continue
        else:
            k = k + 1
            s = str(k)
            for name in lists:
                s = s + " " + id_protein[name]
            f.write(s)
            f.write('\n')
    f.close()
# ****************************************************************

if __name__ == '__main__':
    dataset = 'CollinsW'
    #dataset = 'GavinW'
    #dataset = 'KroganW'
    print ("you are runing " + dataset + "!")
    n = 2
    print ("standard protein complexes"+str(n))
    lists = '..\datasets/'
    filename = lists + dataset + '.txt'
    relations, label_id, id_label,weight = Read_interactionfile(filename)
    best_GE = 0.7
    best_ratio = 1.0
    inflate = 2.0
    best_fitness, best_cluster = main.main(best_GE,inflate, best_ratio,lists,relations, label_id, id_label,weight)
    print ("best_GE,best_I,best_ratio,best_os,best_fitness=",best_GE,best_ratio)
    print ("best_fitness,len(best_cluster) =", best_fitness, len(best_cluster))
    reference = '../datasets\standardcomplexes' + str(n) + '.txt'
    Proteincomplexes = main.Transformid_label(best_cluster, id_label)
    metricsscore = Measure.evaluation(filename,Proteincomplexes, reference)
    print ("metricsscore =",metricsscore)
    results = '..\Results/' + 'CAMPhso_' + dataset + str(round(best_GE, n)) + "."+ str(round(best_ratio, n)) +".txt"
    CreateResultFile(best_cluster, id_label, f=results)
    print ('END!')