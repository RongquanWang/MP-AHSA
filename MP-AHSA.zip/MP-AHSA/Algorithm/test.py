import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from Algorithm import main
import random
from collections import defaultdict
import math
import string
from Metrics import Measure
from numpy.matlib import zeros

# ****************************************************************
def Read_interactionfile(filename):
    relations = defaultdict(list)
    label_id = {}
    id_label = {}
    total = 0
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        # print "start_name =",start_name
        end_name = line_interaction[1].strip();
        # print "end_name =",end_name
        # weightid = line_interaction[2].strip();
        if start_name not in label_id:
            label_id[start_name] = len(label_id);
            id_label[len(id_label)] = start_name
        if end_name not in label_id:
            label_id[end_name] = len(label_id);
            id_label[len(id_label)] = end_name
        if ((not label_id[start_name] in relations[label_id[end_name]]) and start_name != end_name):
            total = total + 1
            relations[label_id[end_name]].append(label_id[start_name]);
            relations[label_id[start_name]].append(label_id[end_name]);
    print("Total number of interactions(duplications are removed):", total)
    print("Total number of proteins:", len(label_id))

    N = len(label_id)
    weight = zeros((N, N))
    num = 1
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        end_name = line_interaction[1].strip();
        weightid2 = line_interaction[2].strip();
        weightid3 = line_interaction[3].strip();
        weightid4 = line_interaction[4].strip();
        weightid = (float(weightid2)+float(weightid3)+float(weightid4))/3
        #print "start_name,end_name,weight =", start_name,end_name,weightid,num
        num = num + 1
        weight[label_id[start_name], label_id[end_name]] = weightid
        weight[label_id[end_name], label_id[start_name]] = weightid
    return relations, label_id, id_label, weight
# ****************************************************************
def GO_slims(GO_url):
    GOlists = []
    relationsGO = defaultdict(list)
    label_id = {}
    id_label = {}
    read_point = open(GO_url, "r");
    for line in read_point.readlines():
        line_interaction = line.split()
        # print("line_interaction =",line_interaction)
        name1 = line_interaction[0]
        go_exact = line_interaction[2]
        # print("name=", name1,go_exact)
        if go_exact not in GOlists:
            GOlists.append(go_exact)
        if name1 not in label_id:
            label_id[name1] = len(label_id)
            id_label[len(label_id)] = name1
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
        else:
            # id = label_id[name1]
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
    #print("relationsGO=",relationsGO)
    return relationsGO
# ****************************************************************
def Read_subcellularlocalization(filename):
  #print "you are reading interaction file!"
  relationsGO = defaultdict(list)
  relationsSL = defaultdict (list)
  label_id = {}
  id_label = {}
  fes = []
  read_point = open (filename, "r");
  for line in read_point.readlines():
      #line_interaction = string.split(line, "\t")
      line_interaction = line.split()
      #print("line_interaction =", line_interaction)
      name1 = line_interaction[0]
      name3 = line_interaction[2]
      name4 = line_interaction[3]
      #print "name1=",name1
      #print "name3=", name3
      #print "name4=", name4
      if name4 not in fes:
          fes.append(name4)
      if name1 not in label_id:
          label_id[name1] = len(label_id)
          id_label[len(label_id)] = name1
          if name3 not in relationsGO[len(label_id)]:
             relationsGO[len(label_id)].append(name3)
          if name4 not in relationsSL[len(label_id)]:
             relationsSL[len(label_id)].append(name4)
      else:
          id = label_id[name1]
          if name3 not in relationsGO[id]:
             relationsGO[id].append(name3)
          if name4 not in relationsSL[id]:
             relationsSL[id].append(name4)
      #print "===================================="
  #print "The total number of protein is ",len(label_id)
  #print "label_id=",label_id
  #print "id_label=",id_label
  #print "len(fes)=",len(fes)
  #print "fes=",fes
  return label_id,id_label,relationsGO,relationsSL
# ****************************************************************
def subcellular_localization(filesl, id_label_ppi):
    N = len(id_label_ppi)
    label_id, id_label, relationsGO, relationsSL = Read_subcellularlocalization(filesl)
    relationsGO1 = defaultdict(list)
    id_ppi = {}
    for id in id_label_ppi:
        if id_label_ppi[id] in label_id:
            id_ppi[id] = label_id[id_label_ppi[id]]
            relationsGO1[id] = relationsGO[label_id[id_label_ppi[id]]]
    return relationsGO1
# ****************************************************************
def Read_genefile(filename):
    gene_time = defaultdict(list)
    read_point = open(filename,"r");
    for line in read_point.readlines():
        #print(line)
        #line_interaction = string.split(line,"\t")
        line_interaction = line.split()
        #print("line_interaction =",line_interaction)
        name = line_interaction[0]
        #print "type(name)=",type(name):str
        #gene = name.split(" ")
        #print "gene=",gene
        #protein_name = gene[0]
        #print "protein_name =", protein_name
        time_value = line_interaction[1:]
        gene_time[name] = time_value
        #print("gene_time[name]=",gene_time[name])
    for index in gene_time:
        #print index
        #print (gene_time[index])
        time_list = []
        str_float = gene_time[index]
        #print("str_float=",str_float)
        #print type(str_float)
        for id in str_float:
            id = float(id)
            #value = string.atof(id)
            time_list.append(id)
        gene_time[index] = time_list
        #print ("gene_time[index]",time_list)
    #print "gene_time=",gene_time
    return gene_time
# ****************************************************************
def name_to_id(lable_id,gene_times):
    gene = defaultdict(list)
    for id in lable_id:
        if id in gene_times:
            gene[lable_id[id]] = gene_times[id]
        else:
            continue
    return gene
# ****************************************************************
def gene_expression_weight(label_id, GE_url):
    #fileg = 'C:\Users\Wang-PC\Desktop\MCGEDP\gene_coexpress_data.txt'
    gene_time = Read_genefile(GE_url)
    # print "len(gene_time)=", len(gene_time)
    gene_time = name_to_id(label_id,gene_time)
    return gene_time
# ****************************************************************
def CreateResultFile(seedt,id_protein,f ="Result.txt"):
    f = open(f,'w')
    k = 0
    for id in seedt:
        lists = seedt[id]
        if len(lists) < 3:
            continue
        else:
            k = k + 1
            s = str(k)
            for name in lists:
                s = s + " " + id_protein[name]
            f.write(s)
            f.write('\n')
    f.close()
# ****************************************************************

if __name__ == '__main__':
    dataset = 'CollinsW'
    #dataset = 'GavinW'
    #dataset = 'KroganW'
    dataset = 'DIP_PPIW'
    #dataset = 'BiogridW'
    #dataset = 'StringW'
    # print "***************************************************************"
    print ("you are runing " + dataset + "!")
    n = 2
    print ("standard protein complexes"+str(n))
    lists = '..\datasets/'
    filename = lists + dataset + '.txt'
    relations, label_id, id_label,weight = Read_interactionfile(filename)

    # print "***************************************************************"
    GO_url = '..\datasets/Go_slim_mapping1.txt'
    relationsGO = GO_slims(GO_url)
    # print "relationsGO=",relationsGO
    # print "***************************************************************"
    SL_url = lists + 'Subcellular_localization.txt'
    relationsSL = subcellular_localization(SL_url, id_label)
    # print "relationsSL=",relationsSL
    # print "***************************************************************"
    GE_url = lists + 'gene_expression_data.txt'
    gene_expressionfiles = gene_expression_weight(label_id, GE_url)
    # print "***************************************************************"
    best_GE = 0.7
    best_inflate = 2.0
    best_ratio = 0.9
    best_fitness, best_cluster = main.main(best_GE,best_inflate,best_ratio,relations,id_label,weight,relationsGO,relationsSL,gene_expressionfiles)
    print ("best_GE,best_inflate,best_ratio,best_fitness,len(best_cluster)=",best_GE,best_inflate,best_ratio,best_fitness,len(best_cluster))
    reference = '../datasets\standardcomplexes' + str(n) + '.txt'
    Proteincomplexes = main.Transformid_label(best_cluster, id_label)
    # print "***************************************************************"
    metricsscore = Measure.evaluation(filename,Proteincomplexes, reference)
    print ("metricsscore =",metricsscore)
    results = '..\Metrics/' + 'MP-AHSA_' + dataset +".txt"
    CreateResultFile(best_cluster, id_label, f=results)
    # print "***************************************************************"
    print ('END!')