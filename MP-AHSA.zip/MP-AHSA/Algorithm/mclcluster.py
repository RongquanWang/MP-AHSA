import sys
from collections import defaultdict
from optparse import OptionParser
import string
import numpy as np
import math
import time
import logging
import networkx as nx

###########################################################################
def get_clusters(A):
    clusters = []
    for i, r in enumerate((A > 0).tolist()):
        if r[i]:
            clusters.append(A[i,:] > 0)
    clust_map ={}
    for cn , c in enumerate(clusters):
        for x in [ i for i,x in enumerate(c) if x]:
            clust_map[cn] = clust_map.get(cn,[]) + [x]
    return clust_map
###########################################################################
def stop(M, i):
    if i%5 == 4:
        m = np.max( M**2 - M) - np.min(M**2 - M)
        if m==0:
            logging.info("Stop at iteration %s" % i)
            return True
    return False
###########################################################################
def inflate(A, inflate_factor):
    return normalize(np.power(A, inflate_factor))
###########################################################################
def expand(A, expand_factor):
    return np.linalg.matrix_power(A, expand_factor)
###########################################################################
def normalize(A):
    column_sums = A.sum(axis=0)
    new_matrix = A / column_sums[np.newaxis, :]
    return new_matrix
###########################################################################
def add_diag(A, mult_factor):
    return A + mult_factor * np.identity(A.shape[0])
###########################################################################
def mcl(M,expand_factor = 2, inflate_factor = 2, max_loop = 100,mult_factor = 1):
    M = add_diag(M, mult_factor)
    M = normalize(M)
    '''
    change = 1
    while (change):
        M2 = inflate(M,inflate_factor)
        M1 = expand(M,expand_factor)
        if ((M1 == M2).all()):
            change = 0
        else:
            change = 1
    clusters = get_clusters(M)
    '''
    for i in range(max_loop):
      #print ("loop", i)
      M = inflate(M,inflate_factor)
      M = expand(M,expand_factor)
      if stop(M, i): break
    clusters = get_clusters(M)
    return M, clusters
################################################################
def my_mcl_cluster(g,weighted = False, e = 2, i = 2.0, l =100, m = 1):
    _nodes = np.array(g.nodes())
    if weighted:
        _matrix = np.array(nx.adjacency_matrix(g, _nodes, 'w').todense())
    else:
        _matrix = np.array(nx.adjacency_matrix(g, _nodes).todense())
    M, clusters = mcl(_matrix,expand_factor=e,inflate_factor = i,max_loop = l,mult_factor = m)
    return clusters
#############################################################
def Redundancy_filtering(Core_dict,overlapscore):
    iy = 0
    PCs = defaultdict(list)
    for id in Core_dict:
        cluster = Core_dict[id]
        cluster_set = list(set(cluster))
        if len(cluster_set) >= 2:
            PCs[iy] = cluster_set
            iy = iy + 1
    com = defaultdict(list)
    complexk = {}
    # print "seed=",seed
    for index in PCs:
        cluster = PCs[index]
        complexk[index] = len(cluster)
    dict = sorted(complexk.items(), key=lambda d: d[1], reverse=True)
    k = 0
    for indexk in dict:
        #print "indexk=",indexk
        ink = indexk
        #print "ink[0]=",ink[0]
        cluster = PCs[ink[0]]
        #print "cluster =",cluster
        cluster.sort()
        com[k] = cluster
        # print "seed[ink[0]]",seed[ink[0]]
        k = k + 1

    proteincomplexes = com
    visit = []
    for i in range(len(proteincomplexes) - 1):
        if i not in visit:
           for j in range(i + 1, len(proteincomplexes) - 1):
             if j not in visit:
                set1 = set(proteincomplexes[i])
                set2 = set(proteincomplexes[j])
                score = Overlap_matchingscore(set1,set2)
                if score >= overlapscore:
                   visit.append(j)
    #print "visit=",visit
    wrq = defaultdict(list)
    for ib in proteincomplexes:
        #print "ib=",ib
        if len(proteincomplexes) >= 2 and ib not in visit:
            wrq[ib] = proteincomplexes[ib]
    wrq1 = defaultdict(list)
    ij = 0
    for id in wrq:
        cluster = wrq[id]
        cluster.sort()
        wrq1[ij] = cluster
        ij = ij + 1
    #print "***************************************************************"
    #for id in wrq1:
    #    print "wrq1[id]=",id,wrq1[id]
    return wrq1
#############################################################
def Overlap_matchingscore(Cluster_A,Cluster_B):
    Cluster_A = set(Cluster_A)
    Cluster_B = set(Cluster_B)
    overlap_set = Cluster_A & Cluster_B
    overlap_num = float(len(overlap_set))
    Cluster_A_size = float(len (Cluster_A))
    Cluster_B_size = float(len(Cluster_B))
    O_A_B = (overlap_num * overlap_num) / (Cluster_A_size * Cluster_B_size)
    return O_A_B
################################################################
def mclclusters(id_label,relations,I,iter,weights):
    graph = nx.Graph()
    for id in id_label:
        neighbors_id = relations[id]
        for it in neighbors_id:
            if it > id:
               graph.add_edge(id,it, w=weights[id,it])
               #graph.add_edge(id, it, w=1.0)
    clusters = my_mcl_cluster(graph, weighted=True, e=2, i=I,l=iter, m=1)
    clusters = Redundancy_filtering(clusters,1.0)
    return clusters