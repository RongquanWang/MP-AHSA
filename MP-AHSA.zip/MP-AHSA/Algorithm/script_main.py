import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

from Algorithm import main
import random
from collections import defaultdict
import math
import string
from Metrics import Measure
from numpy.matlib import zeros
import time
import copy

# ****************************************************************
def Read_interactionfile(filename):
    relations = defaultdict(list)
    label_id = {}
    id_label = {}
    total = 0
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        # print "start_name =",start_name
        end_name = line_interaction[1].strip();
        # print "end_name =",end_name
        # weightid = line_interaction[2].strip();
        if start_name not in label_id:
            label_id[start_name] = len(label_id);
            id_label[len(id_label)] = start_name
        if end_name not in label_id:
            label_id[end_name] = len(label_id);
            id_label[len(id_label)] = end_name
        if ((not label_id[start_name] in relations[label_id[end_name]]) and start_name != end_name):
            total = total + 1
            relations[label_id[end_name]].append(label_id[start_name]);
            relations[label_id[start_name]].append(label_id[end_name]);
    print("Total number of interactions(duplications are removed):", total)
    print("Total number of proteins:", len(label_id))

    N = len(label_id)
    weight = zeros((N, N))
    num = 1
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        end_name = line_interaction[1].strip();
        weightid2 = line_interaction[2].strip();
        weightid3 = line_interaction[3].strip();
        weightid4 = line_interaction[4].strip();
        weightid = (float(weightid2)+float(weightid3)+float(weightid4))/3
        #print "start_name,end_name,weight =", start_name,end_name,weightid,num
        num = num + 1
        weight[label_id[start_name], label_id[end_name]] = weightid
        weight[label_id[end_name], label_id[start_name]] = weightid
    return relations, label_id, id_label, weight
# ****************************************************************
def GO_slims(GO_url):
    GOlists = []
    relationsGO = defaultdict(list)
    label_id = {}
    id_label = {}
    read_point = open(GO_url, "r");
    for line in read_point.readlines():
        line_interaction = line.split()
        # print("line_interaction =",line_interaction)
        name1 = line_interaction[0]
        go_exact = line_interaction[2]
        # print("name=", name1,go_exact)
        if go_exact not in GOlists:
            GOlists.append(go_exact)
        if name1 not in label_id:
            label_id[name1] = len(label_id)
            id_label[len(label_id)] = name1
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
        else:
            # id = label_id[name1]
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
    #print("relationsGO=",relationsGO)
    return relationsGO
# ****************************************************************
def Read_subcellularlocalization(filename):
  #print "you are reading interaction file!"
  relationsGO = defaultdict(list)
  relationsSL = defaultdict (list)
  label_id = {}
  id_label = {}
  fes = []
  read_point = open (filename, "r");
  for line in read_point.readlines():
      #line_interaction = string.split(line, "\t")
      line_interaction = line.split()
      #print("line_interaction =", line_interaction)
      name1 = line_interaction[0]
      name3 = line_interaction[2]
      name4 = line_interaction[3]
      #print "name1=",name1
      #print "name3=", name3
      #print "name4=", name4
      if name4 not in fes:
          fes.append(name4)
      if name1 not in label_id:
          label_id[name1] = len(label_id)
          id_label[len(label_id)] = name1
          if name3 not in relationsGO[len(label_id)]:
             relationsGO[len(label_id)].append(name3)
          if name4 not in relationsSL[len(label_id)]:
             relationsSL[len(label_id)].append(name4)
      else:
          id = label_id[name1]
          if name3 not in relationsGO[id]:
             relationsGO[id].append(name3)
          if name4 not in relationsSL[id]:
             relationsSL[id].append(name4)
      #print "===================================="
  #print "The total number of protein is ",len(label_id)
  #print "label_id=",label_id
  #print "id_label=",id_label
  #print "len(fes)=",len(fes)
  #print "fes=",fes
  return label_id,id_label,relationsGO,relationsSL
# ****************************************************************
def subcellular_localization(filesl, id_label_ppi):
    N = len(id_label_ppi)
    label_id, id_label, relationsGO, relationsSL = Read_subcellularlocalization(filesl)
    relationsGO1 = defaultdict(list)
    id_ppi = {}
    for id in id_label_ppi:
        if id_label_ppi[id] in label_id:
            id_ppi[id] = label_id[id_label_ppi[id]]
            relationsGO1[id] = relationsGO[label_id[id_label_ppi[id]]]
    return relationsGO1
# ****************************************************************
def SLcodes(relationsSL):
    i = 0
    SL_dicts = {}
    SL_name = []
    for id in relationsSL:
        SL_features = relationsSL[id]
        for it in SL_features:
            if it not in SL_name:
                SL_name.append(it)
                SL_dicts[it] = i
                i = i + 1
    SL_codes = defaultdict(list)
    for iw in relationsSL:
        iw_relationsSL = relationsSL[iw]
        lists = []
        for iz in iw_relationsSL:
            if iz in SL_dicts:
                lists.append(SL_dicts[iz])
        SL_codes[iw] = lists
    return SL_codes
# ****************************************************************
def Read_genefile(filename):
    gene_time = defaultdict(list)
    read_point = open(filename,"r");
    for line in read_point.readlines():
        #print(line)
        #line_interaction = string.split(line,"\t")
        line_interaction = line.split()
        #print("line_interaction =",line_interaction)
        name = line_interaction[0]
        #print "type(name)=",type(name):str
        #gene = name.split(" ")
        #print "gene=",gene
        #protein_name = gene[0]
        #print "protein_name =", protein_name
        time_value = line_interaction[1:]
        gene_time[name] = time_value
        #print("gene_time[name]=",gene_time[name])
    for index in gene_time:
        #print index
        #print (gene_time[index])
        time_list = []
        str_float = gene_time[index]
        #print("str_float=",str_float)
        #print type(str_float)
        for id in str_float:
            id = float(id)
            #value = string.atof(id)
            time_list.append(id)
        gene_time[index] = time_list
        #print ("gene_time[index]",time_list)
    #print "gene_time=",gene_time
    return gene_time
# ****************************************************************
def name_to_id(lable_id,gene_times):
    gene = defaultdict(list)
    for id in lable_id:
        if id in gene_times:
            gene[lable_id[id]] = gene_times[id]
        else:
            continue
    return gene
# ****************************************************************
def gene_expression_weight(label_id, GE_url):
    #fileg = 'C:\Users\Wang-PC\Desktop\MCGEDP\gene_coexpress_data.txt'
    gene_time = Read_genefile(GE_url)
    # print "len(gene_time)=", len(gene_time)
    gene_time = name_to_id(label_id,gene_time)
    return gene_time
# ****************************************************************
def roulettewheel(seed_node_sort):
    #print("HM_fitness=",seed_node_sort)
    seed_node_sort1 = copy.deepcopy(seed_node_sort)
    points = list(seed_node_sort1.keys())
    for ib in points:
        if seed_node_sort1[ib] == 0.0:
            del seed_node_sort1[ib]
    Seeds = 0
    Left_point = list(seed_node_sort1.keys())
    selection_prob = {}
    sum_weights = 0.0
    for id in Left_point:
        sum_weights = sum_weights + seed_node_sort1[id]
    sum = 0.0
    scoreid = {}
    for it in Left_point:
        selection_prob[it] = seed_node_sort1[it] / sum_weights
        sum = sum + selection_prob[it]
        scoreid[sum] = it

    #print("scoreid=",scoreid)
    random_value = random.random()
    #print("random_value =",random_value)
    for score in scoreid:
        if score > random_value:
            Seeds=scoreid[score]
            #print("choiceid=", scoreid[score])
            break
    #print("choice_HM =", Seeds)
    return Seeds
# ****************************************************************
def CreateResultFile(seedt,id_protein,f ="Result.txt"):
    f = open(f,'w')
    k = 0
    for id in seedt:
        lists = seedt[id]
        if len(lists) < 3:
            continue
        else:
            k = k + 1
            s = str(k)
            for name in lists:
                s = s + " " + id_protein[name]
            f.write(s)
            f.write('\n')
    f.close()
# ****************************************************************

if __name__ == '__main__':
    starttime = time.time()
    dataset = 'CollinsW'
    #dataset = 'GavinW'
    dataset = 'KroganW'
    dataset = 'DIP_PPIW'
    #dataset = 'BiogridW'
    #dataset = 'StringW'
    # print "***************************************************************"
    print ("you are runing " + dataset + "!")
    n = 2
    print ("standard protein complexes"+str(n))
    lists = '..\datasets/'
    filename = lists + dataset + '.txt'
    relations, label_id, id_label,weight = Read_interactionfile(filename)

    # print "***************************************************************"
    GO_url = '..\datasets/Go_slim_mapping1.txt'
    relationsGO = GO_slims(GO_url)
    # print "relationsGO=",relationsGO
    # print "***************************************************************"
    SL_url = lists + 'Subcellular_localization.txt'
    relationsSL = subcellular_localization(SL_url, id_label)
    SL_codes = SLcodes(relationsSL)
    # print "relationsSL=",relationsSL
    # print "***************************************************************"
    GE_url = lists + 'gene_expression_data.txt'
    gene_expressionfiles = gene_expression_weight(label_id, GE_url)
    # print "***************************************************************"
    GEmin = 0.5
    GEmax = 1.0
    inflatemax = 4.0
    inflatemin = 1.0
    ratiomin = 0.8
    ratiomax = 1.0

    HMCRmax= 0.95 #0.7-0.95
    HMCRmin = 0.7 # 0.7-0.95
    PARmax= 0.5 # 0.1-0.5
    PARmin = 0.1 # 0.1-0.5
    FWmax = 0.1 #0.01-0.1
    FWmin = 0.01 # 0.01-0.1

    count = 0.0
    HMS = 30  # 20-200
    Maxiter = 300
    # print "***************************************************************"
    i = 1
    HM = defaultdict(list)
    HM_fitness = {}
    best_cluster = defaultdict(list)
    fitnessavg = 0.0
    for i in range(HMS):
        GE_value = GEmin + (GEmax-GEmin)*random.uniform(0.0, 1.0)
        inflate_value = inflatemin + (inflatemax - inflatemin) * random.uniform(0.0, 1.0)
        ratio_value = ratiomin + (ratiomax - ratiomin) * random.uniform(0.0, 1.0)
        HM[i].append(GE_value)
        HM[i].append(inflate_value)
        HM[i].append(ratio_value)
        fitnessi, Proteincomplexesi = main.main(GE_value,inflate_value,ratio_value,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
        #print("Proteincomplexesi =",Proteincomplexesi)
        #print "=========================================="
        HM_fitness[i] = fitnessi
        fitnessavg = fitnessavg + fitnessi
        count = count + 1
        if count % 30 == 0:
            print("finish%=", count * 100 / (HMS + Maxiter), "%")
    # print "***************************************************************"
    fitnessavg = fitnessavg/len(HM_fitness)
    fitnessmax = max(HM_fitness)
    fitnessmin = min(HM_fitness)
    j = 0
    while j < Maxiter:
       current_fitness = 0.0
       current_GE = 0.0
       current_inflate = 0.0
       current_ratio = 0.0
       current_cluster = defaultdict(list)
       mark = 0
       rand1 = random.uniform(0.0, 1.0)
       HMCR = HMCRmin + (HMCRmax - HMCRmin)*float(j/Maxiter)
       if rand1 > HMCR:
           current_GE = GEmin + (GEmax - GEmin) * random.uniform(0.0, 1.0)
           current_inflate = inflatemin + (inflatemax - inflatemin) * random.uniform(0.0, 1.0)
           current_ratio = ratiomin + (ratiomax - ratiomin) * random.uniform(0.0, 1.0)
           current_fitness, current_cluster = main.main(current_GE, current_inflate, current_ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
       else:
           HMS_keys = HM.keys()
           HMS_keys1 = list(HMS_keys)
           choice_HM = roulettewheel(HM_fitness)
           select_HM = choice_HM
           #select_HM = random.choice(HMS_keys1)
           #print("select_HM =",select_HM)
           current_GE = HM[select_HM][0]
           current_inflate = HM[select_HM][1]
           current_ratio = HM[select_HM][2]
           current_fitness = HM_fitness[select_HM]
           mark = 1

       fitnessmax = max(HM_fitness)
       fitnessmin = min(HM_fitness)
       FW = FWmin + (FWmax - FWmin) * (float(fitnessmax - current_fitness)*float(Maxiter - j) / ((fitnessmax - fitnessmin)* Maxiter))
       #FW = FWmax - (FWmax - FWmin) * float(j) / Maxiter
       #FW = FWmin + random.uniform(FWmin, FWmax)* float(Maxiter-j) / Maxiter
       if mark == 1:
          rand2 = random.uniform(0.0, 1.0)
          PAR = PARmax-float(j)/Maxiter*(PARmax-PARmin)
          if PAR < rand2:
              rand3 = random.uniform(0.0, 1.0)
              if rand3 > 0.5:
                 current_GE = HM[select_HM][0] +FW*(GEmax - GEmin)
                 current_inflate = HM[select_HM][1]+ FW*(inflatemax - inflatemin)
                 current_ratio = HM[select_HM][2] +FW*(ratiomax - ratiomin)
                 current_fitness, current_cluster = main.main(current_GE,current_inflate,current_ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
              else:
                 current_GE = HM[select_HM][0] - FW * (GEmax - GEmin)
                 current_inflate = HM[select_HM][1] + FW * (inflatemax - inflatemin)
                 current_ratio = HM[select_HM][2] - FW * (ratiomax - ratiomin)
                 current_fitness, current_cluster = main.main(current_GE,current_inflate,current_ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
       else:
           rand4 = random.uniform(0.0, 1.0)
           if rand4 > 0.5:
               current_GE = current_GE + FW * (GEmax - GEmin)
               current_inflate = current_inflate + FW * (inflatemax - inflatemin)
               current_ratio = current_ratio + FW * (ratiomax - ratiomin)
               current_fitness, current_cluster = main.main(current_GE,current_inflate,current_ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
           else:
               current_GE = current_GE - FW * (GEmax - GEmin)
               current_inflate = current_inflate + FW * (inflatemax - inflatemin)
               current_ratio = current_ratio - FW * (ratiomax - ratiomin)
               current_fitness, current_cluster = main.main(current_GE,current_inflate,current_ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
       #print("current_cluster =",current_cluster)
       # print "***************************************************************"
       d2 = sorted(HM_fitness.items(), key=lambda HM_fitness: HM_fitness[1], reverse=False)
       HMmin = d2[0]
       if current_fitness > HMmin[1]:
          HM[HMmin[0]][0] = current_GE
          HM[HMmin[0]][1] = current_inflate
          HM[HMmin[0]][2] = current_ratio
          HM_fitness[HMmin[0]] = current_fitness
          #print ("Iters =", j)
          #print ("HMmin =", HMmin)
          #print ("HM_fitness[HMmin[0]]=",HM_fitness[HMmin[0]])
          #print("##########################################################")
       j = j + 1
       count = count + 1
       if count % ((HMS + Maxiter)/10) == 0:
           print("finish%=", count * 100 / (HMS + Maxiter), "%")
    # print "***************************************************************"
    d2 = sorted(HM_fitness.items(), key=lambda HM_fitness: HM_fitness[1], reverse=True)
    HMmax = d2[0]
    print("up-down =", d2)
    print("HMmax =", HMmax)
    best_GE = HM[HMmax[0]][0]
    best_inflate = HM[HMmax[0]][1]
    best_ratio = HM[HMmax[0]][2]
    best_fitness, best_cluster = main.main(best_GE,best_inflate,best_ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles)
    print ("best_GE,best_inflate,best_ratio,best_fitness,len(best_cluster)=",best_GE,best_inflate,best_ratio,best_fitness,len(best_cluster))
    reference = '../datasets\standardcomplexes' + str(n) + '.txt'
    Proteincomplexes = main.Transformid_label(best_cluster, id_label)
    # print "***************************************************************"
    metricsscore = Measure.evaluation(filename,Proteincomplexes, reference)
    print ("metricsscore =",metricsscore)
    results = '..\Results/' + 'MP-AHSA_' + dataset+".txt"
    CreateResultFile(best_cluster, id_label, f=results)
    # print "***************************************************************"
    endtime = time.time()
    print("Cost time=",endtime-starttime)
    print ('END!')