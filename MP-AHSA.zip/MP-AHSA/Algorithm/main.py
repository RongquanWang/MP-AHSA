import time
from collections import defaultdict
from numpy.matlib import zeros
import math
import random
import string
import numpy as np
import mclcluster
import copy
#from Metrics.Measure import evaluation
import networkx as nx


def Read_interactionfile(filename):
    relations = defaultdict(list)
    label_id = {}
    id_label = {}
    total = 0
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        # print "start_name =",start_name
        end_name = line_interaction[1].strip();
        # print "end_name =",end_name
        # weightid = line_interaction[2].strip();
        if start_name not in label_id:
            label_id[start_name] = len(label_id);
            id_label[len(id_label)] = start_name
        if end_name not in label_id:
            label_id[end_name] = len(label_id);
            id_label[len(id_label)] = end_name
        if ((not label_id[start_name] in relations[label_id[end_name]]) and start_name != end_name):
            total = total + 1
            relations[label_id[end_name]].append(label_id[start_name]);
            relations[label_id[start_name]].append(label_id[end_name]);
    print("Total number of interactions(duplications are removed):", total)
    print("Total number of proteins:", len(label_id))

    N = len(label_id)
    weight = zeros((N, N))
    num = 1
    read_point = open(filename, "r");
    for line in read_point.readlines():
        line_interaction = line.strip().split()
        start_name = line_interaction[0].strip();
        end_name = line_interaction[1].strip();
        weightid2 = line_interaction[2].strip();
        weightid3 = line_interaction[3].strip();
        weightid4 = line_interaction[4].strip();
        weightid = (float(weightid2)+float(weightid3)+float(weightid4))/3
        #print "start_name,end_name,weight =", start_name,end_name,weightid,num
        num = num + 1
        weight[label_id[start_name], label_id[end_name]] = weightid
        weight[label_id[end_name], label_id[start_name]] = weightid
    return relations, label_id, id_label, weight
# ***************************************************************
def GO_slims(GO_url, relations, name_id):
    GOlists = []
    relationsGO = defaultdict(list)
    label_id = {}
    id_label = {}
    read_point = open(GO_url, "r");
    for line in read_point.readlines():
        line_interaction = line.split()
        # print("line_interaction =",line_interaction)
        name1 = line_interaction[0]
        go_exact = line_interaction[2]
        # print("name=", name1,go_exact)
        if go_exact not in GOlists:
            GOlists.append(go_exact)
        if name1 not in label_id:
            label_id[name1] = len(label_id)
            id_label[len(label_id)] = name1
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
        else:
            # id = label_id[name1]
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
    #print("relationsGO=",relationsGO)
    N1 = len(name_id)
    N2 = len(GOlists)
    goname_id = {}
    id_goname = {}
    i = 0
    weight = zeros((N1, N2))
    for goname in GOlists:
        goname_id[goname] = i
        id_goname[i] = goname
        i = i + 1
    for protein_id in relationsGO:
        if protein_id in name_id:
            lists_id = relationsGO[protein_id]
            for name in lists_id:
                weight[name_id[protein_id], goname_id[name]] = 1
    #print "relationsGO=",relationsGO
    Weight_fa = zeros((N1, N1))
    for id in name_id:
        idi = name_id[id]
        neighbor_id = relations[idi]
        for it in neighbor_id:
            if it > idi:
                vector_a = np.mat(weight[idi])
                vector_b = np.mat(weight[it])
                num = float(vector_a * vector_b.T)
                denom = np.linalg.norm(vector_a) * np.linalg.norm(vector_b)
                if denom > 0.0:
                    cos = num / denom
                else:
                    cos = 0.0
                Weight_fa[idi, it] = cos
                Weight_fa[it, idi] = cos
                #print("cos=",cos)
    return Weight_fa, relationsGO
# ***************************************************************
def GO_slims1(GO_url, relations, name_id):
    GOlists = []
    relationsGO = defaultdict(list)
    label_id = {}
    id_label = {}
    read_point = open(GO_url, "r");
    for line in read_point.readlines():
        line_interaction = line.split()
        # print("line_interaction =",line_interaction)
        name1 = line_interaction[0]
        go_exact = line_interaction[2]
        # print("name=", name1,go_exact)
        if go_exact not in GOlists:
            GOlists.append(go_exact)
        if name1 not in label_id:
            label_id[name1] = len(label_id)
            id_label[len(label_id)] = name1
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)
        else:
            # id = label_id[name1]
            if go_exact not in relationsGO[name1] and go_exact != '':
                relationsGO[name1].append(go_exact)

    #print ("relationsGO=",relationsGO)
    N1 = len(id_label)
    weight = zeros((N1, N1))
    for id in id_label:
        if id_label[id] in relationsGO:
            neighbors = relations[id]
            for it in neighbors:
                if it > id:
                  if id_label[it] in relationsGO:
                    id1_listGO = relationsGO[id_label[id]]
                    id2_listGO = relationsGO[id_label[it]]
                    #print (id1_listGO)
                    #print (id2_listGO)
                    weight_idit = len(set(id1_listGO)& set(id2_listGO))/(len(id1_listGO)*len(id1_listGO))
                    #print ("weight_idit =",weight_idit)
                    weight[id,it] = weight_idit
                    weight[it,id] = weight_idit
    return weight, relationsGO
# ***************************************************************
def Read_genefile(filename):
    gene_time = defaultdict(list)
    read_point = open(filename,"r");
    for line in read_point.readlines():
        #print(line)
        #line_interaction = string.split(line,"\t")
        line_interaction = line.split()
        #print("line_interaction =",line_interaction)
        name = line_interaction[0]
        #print "type(name)=",type(name):str
        #gene = name.split(" ")
        #print "gene=",gene
        #protein_name = gene[0]
        #print "protein_name =", protein_name
        time_value = line_interaction[1:]
        gene_time[name] = time_value
        #print("gene_time[name]=",gene_time[name])
    for index in gene_time:
        #print index
        #print (gene_time[index])
        time_list = []
        str_float = gene_time[index]
        #print("str_float=",str_float)
        #print type(str_float)
        for id in str_float:
            id = float(id)
            #value = string.atof(id)
            time_list.append(id)
        gene_time[index] = time_list
        #print ("gene_time[index]",time_list)
    #print "gene_time=",gene_time
    return gene_time
#******************************************************
def name_to_id(lable_id,gene_times):
    gene = defaultdict(list)
    for id in lable_id:
        if id in gene_times:
            gene[lable_id[id]] = gene_times[id]
        else:
            continue
    return gene
#******************************************************
def multipl(a,b):
    sumofab=0.0
    for i in range(len(a)):
        temp=a[i]*b[i]
        sumofab+=temp
    return sumofab
#******************************************************
def protein_protein_PCC(node1, node2):
    timenode1 = np.array(node1)
    # print "timenode1 =",timenode1
    timenode2 = np.array(node2)
    # print "timenode2 =", timenode2
    n = len(timenode1)
    sumnode1 = sum(timenode1)
    sumnode2 = sum(timenode2)
    sumofxy = multipl(timenode1,timenode2)
    sumofx2 = sum([pow(i,2) for i in timenode1])
    sumofy2 = sum([pow(j,2) for j in timenode2])
    num = sumofxy-(float(sumnode1)*float(sumnode2)/n)
    corrcoef = math.sqrt((sumofx2-float(sumnode1**2)/n)*(sumofy2-float(sumnode2**2)/n))
    pcc = float(num)/corrcoef
    pcc = float(pcc + 1.0) / 2
    return pcc
# ******************************************************
def Give_weights(relations,gene,weight):
    gene_list = gene.keys()
    #print "gene_list=",gene_list
    for id in relations:
        neighobrs = relations[id]
        #print("neighobrs =",neighobrs)
        #print("gene=",gene)
        for it in neighobrs:
           #print("id,it=",id,it)
           if id < it:
              weight2 = 0.0
              score1 = gene[id]
              score2 = gene[it]
              if id not in gene_list or it not in gene_list:
                  #print "To be here!"
                  weight2 = 0.5
              else:
                  if len(score1) > 0.0 and len(score2) > 0.0:
                     #print(score1,score2)
                     weight2 = protein_protein_PCC(score1,score2)
              weight[id,it] = weight2
              weight[it,id] = weight2
           else:
              continue
    return weight
#******************************************************
def gene_expression_weight(relations, label_id, GE_url):
    #fileg = 'C:\Users\Wang-PC\Desktop\MCGEDP\gene_coexpress_data.txt'
    gene_time = Read_genefile(GE_url)
    # print "len(gene_time)=", len(gene_time)
    gene_time = name_to_id(label_id,gene_time)
    #print "len(gene_time)=", len(gene_time)
    #print "geme_time=", gene_time
    weight = zeros((len(label_id),len(label_id)))
    weight = Give_weights(relations,gene_time,weight)
    return weight,gene_time

# ****************************************************************
def Read_subcellularlocalization(filename):
  #print "you are reading interaction file!"
  relationsGO = defaultdict(list)
  relationsSL = defaultdict (list)
  label_id = {}
  id_label = {}
  fes = []
  read_point = open (filename, "r");
  for line in read_point.readlines():
      #line_interaction = string.split(line, "\t")
      line_interaction = line.split()
      #print("line_interaction =", line_interaction)
      name1 = line_interaction[0]
      name3 = line_interaction[2]
      name4 = line_interaction[3]
      #print "name1=",name1
      #print "name3=", name3
      #print "name4=", name4
      if name4 not in fes:
          fes.append(name4)
      if name1 not in label_id:
          label_id[name1] = len(label_id)
          id_label[len(label_id)] = name1
          if name3 not in relationsGO[len(label_id)]:
             relationsGO[len(label_id)].append(name3)
          if name4 not in relationsSL[len(label_id)]:
             relationsSL[len(label_id)].append(name4)
      else:
          id = label_id[name1]
          if name3 not in relationsGO[id]:
             relationsGO[id].append(name3)
          if name4 not in relationsSL[id]:
             relationsSL[id].append(name4)
      #print "===================================="
  #print "The total number of protein is ",len(label_id)
  #print "label_id=",label_id
  #print "id_label=",id_label
  #print "len(fes)=",len(fes)
  #print "fes=",fes
  return label_id,id_label,relationsGO,relationsSL
# ****************************************************************
def GO_similarity(id1_listGO, id2_listGO):
    # print id1_listGO
    # print id2_listGO
    lists = {}
    lists1 = {}
    i = 1
    for it in id1_listGO:
        lists[i] = it
        i = i + 1
    i1 = 1
    for it1 in id2_listGO:
        lists1[i1] = it1
        i1 = i1 + 1
    # print "lists=",lists
    # print "lists1=",lists1
    GO_common = []
    GO_different = []
    for id in lists1:
        # print lists1[id]
        if lists1[id] in id1_listGO:
            GO_common.append(lists1[id])
        else:
            GO_different.append(lists1[id])
    for id1 in lists:
        if lists[id1] not in GO_common:
            GO_different.append(lists[id1])
    if min(len(id1_listGO), len(id2_listGO)) >= 1:
        score = float(len(GO_common)) / min(len(id1_listGO), len(id2_listGO))
        # score = float(len(GO_common)**2) / (len(id1_listGO)*len(id2_listGO))
        # score = float(len(GO_common)) / len(set(id1_listGO) | set(id2_listGO))
        # score = float(2 * len(GO_common)) / (len(id1_listGO) + len(id2_listGO))
    else:
        score = 0.0
    return score
# ****************************************************************
def subcellular_localization_similarity(id1, id2, relationsGO):
    id1_listGO = relationsGO[id1]
    id2_listGO = relationsGO[id2]
    GO_score = GO_similarity(id1_listGO, id2_listGO)
    return GO_score
# ****************************************************************
def subcellular_localization(filesl, relations, id_label_ppi):
    N = len(id_label_ppi)
    weight = zeros((N, N))
    label_id, id_label, relationsGO, relationsSL = Read_subcellularlocalization(filesl)
    relationsGO1 = defaultdict(list)
    id_ppi = {}
    sum_score = 0.0
    count = 0
    for id in id_label_ppi:
        if id_label_ppi[id] in label_id:
            id_ppi[id] = label_id[id_label_ppi[id]]
            relationsGO1[id] = relationsGO[label_id[id_label_ppi[id]]]
    for it in id_label_ppi:
        if it not in relationsGO1:
            continue
        else:
            neighbor = relations[it]
            for ih in neighbor:
                if ih > it:
                    if ih not in relationsGO1:
                        continue
                    else:
                        weight[it, ih] = subcellular_localization_similarity(it, ih, relationsGO1)
                        weight[ih, it] = subcellular_localization_similarity(it, ih, relationsGO1)
                        sum_score = sum_score + weight[it, ih]
                        count = count + 1
    return weight, relationsGO1
# ****************************************************************
def GO_SL(filename):
    name_sl = defaultdict(list)
    slnamelist = ['Nucleus', 'Cytosol', 'Cytoskeleton', 'Peroxisome', 'Lysosome', 'Endoplasmic', 'Golgi', 'Plasma',
                  'Endosome', 'Extracellular', 'Mitochondrion', 'Vacuole']
    id_label1 = {1: 'Nucleus', 2: 'Cytosol', 3: 'Cytoskeleton', 4: 'Peroxisome', 5: 'Lysosome', 6: 'Endoplasmic',
                 7: 'Golgi', 8: 'Plasma', 9: 'Endosome', 10: 'Extracellular', 11: 'Mitochondrion', 12: 'Vacuole'}
    label_id = {'Nucleus': 1, 'Cytosol': 2, 'Cytoskeleton': 3, 'Peroxisome': 4, 'Lysosome': 5, 'Endoplasmic': 6,
                'Golgi': 7, 'Plasma': 8, 'Endosome': 9, 'Extracellular': 10, 'Mitochondrion': 11, 'Vacuole': 5}
    read_point = open(filename, "r");
    for line in read_point.readlines():
        lists = string.split(line, "\t")
        # print "lists =",lists
        name = lists[0]
        # print "name=",name
        genes = lists[1]
        ls = genes.split()
        # print "ls=",ls
        if name not in name_sl:
            name_sl[name] = ls
        else:
            SLlist = name_sl[name]
            SLlist.extend(ls)
            name_sl[name] = SLlist

    for id in name_sl:
        id_sl = []
        sl = name_sl[id]
        sl = list(set(sl))
        # print "id,sl=",id,sl
        # print "===================================!"
        for it in sl:
            if it in slnamelist:
                id_sl.append(it)
        name_sl[id] = id_sl
    # print "name_sl =",name_sl
    SL_relations = defaultdict(list)
    for id in name_sl:
        list_sl = []
        sl_id = name_sl[id]
        for it in sl_id:
            if it in label_id:
                list_sl.append(label_id[it])
        SL_relations[id] = list(set(list_sl))
    print("SL_relations=", SL_relations)
    return SL_relations
# ****************************************************************
def SLweight(SL_relations, relations, id_label):
    # print "relations=",relations
    N = len(id_label)
    weight = zeros((N, N))
    for it in relations:
        # print "it=",it
        gene1 = id_label[it]
        if gene1 not in SL_relations:
            continue
        else:
            neighbor = relations[it]
            for ih in neighbor:
                gene2 = id_label[ih]
                if ih > it:
                    if gene2 not in SL_relations:
                        continue
                    else:
                        # print "gene1, gene2=",gene1,gene2
                        weight[it, ih] = subcellular_localization_similarity(gene1, gene2, SL_relations)
                        weight[ih, it] = subcellular_localization_similarity(gene1, gene2, SL_relations)
    return weight
# ****************************************************************
def score_interaction(id, it, relations):
    neighbor = relations[id]
    neighbor1 = relations[it]
    if len(neighbor) <= 1 or len(neighbor1) <= 1:
        score3 = 0.0
    else:
        com = set(neighbor) & set(neighbor1)
        # union = set(neighbor) | set(neighbor1)
        if len(com) >= 1:
            score1 = float(len(com)) ** 2 / (len(neighbor1) * len(neighbor))
            score3 = score1
        else:
            score3 = 0.0
    return score3
# ****************************************************************
def CN(id_protein, relation):
    weight = zeros((len(id_protein), len(id_protein)))
    for id in id_protein:
        neighbor = relation[id]
        for it in neighbor:
            if it > id:
                scores = score_interaction(id, it, relation)
                weight[id, it] = scores
                weight[it, id] = scores
    return weight
# ****************************************************************
def sqrtdensity(graph, relations, weights):
    # print "graph=",graph
    sum_weight = 0.0
    if len(graph) >= 2:
        for id in graph:
            neighbors = relations[id]
            for it in neighbors:
                # print "id,it=",id,it
                if it > id and it in graph:
                    sum_weight = sum_weight + weights[id, it]
        density = 2 * sum_weight * math.sqrt(len(graph)) / (len(graph) * (len(graph) - 1))
    else:
        density = 0.0
    return density
# ****************************************************************
def density(graph, relations, weights):
    # print "graph=",graph
    sum_weight = 0.0
    if len(graph) >= 2:
        for id in graph:
            neighbors = relations[id]
            for it in neighbors:
                # print "id,it=",id,it
                if it > id and it in graph:
                    sum_weight = sum_weight + weights[id, it]
        density = 2 * sum_weight / (len(graph) * (len(graph) - 1))
    else:
        density = 0.0
    return density
# ****************************************************************
def Cohesiveness(graph, weights, relations):
    sum_weight = 0.0
    node_dict = {}
    k = 1
    for id in graph:
        node_dict[k] = id
        k = k + 1
    for it in node_dict:
        for ih in node_dict:
            if ih <= it:
                continue
            else:
                if weights[node_dict[it], node_dict[ih]] > 0.0:
                    sum_weight = sum_weight + weights[node_dict[it], node_dict[ih]]
    sum_out_weight = 0.0
    for id1 in node_dict:
        neighbors = relations[node_dict[id1]]
        for iw in neighbors:
            if iw not in graph:
                sum_out_weight = sum_out_weight + weights[node_dict[id1], iw]
            else:
                continue
    modularitys = 0.0
    if (sum_weight + sum_out_weight) == 0.0 or len(graph) <= 2:
        modularitys = 0.0
    else:
        weightin = sum_weight
        weightout = sum_out_weight
        modularitys = weightin / (weightin + weightout)
    return modularitys
# ****************************************************************
def modularity(graph, relations, weight):
    sum_weight = 0.0
    node_dict = {}
    k = 1
    for id in graph:
        node_dict[k] = id
        k = k + 1
    for it in node_dict:
        for ih in node_dict:
            if ih <= it:
                continue
            else:
                if weight[node_dict[it], node_dict[ih]] > 0.0:
                    sum_weight = sum_weight + weight[node_dict[it], node_dict[ih]]
    sum_out_weight = 0.0
    neighbors_nodes = []
    for id1 in node_dict:
        neighbors = relations[node_dict[id1]]
        for iw in neighbors:
            if iw not in graph:
                sum_out_weight = sum_out_weight + weight[node_dict[id1], iw]
                if iw not in neighbors_nodes:
                   neighbors_nodes.append(iw)

            else:
                continue
    modularitys = 0.0
    if len(neighbors_nodes) <1 or len(graph) <= 2:
        modularitys = 0.0
    else:
        avgdensity = 2 * sum_weight / len(graph)
        avg_out_weight = sum_out_weight / len(neighbors_nodes)
        modularitys = avgdensity / (avgdensity + avg_out_weight)
    return modularitys
# ****************************************************************
def AWM(graph,relations,weight):
    if len(graph) >= 2:
        weight_in = 0.0
        weight_out = 0.0
        edge_in = 0.0
        edge_out = 0.0
        for id in graph:
            neighbor = relations[id]
            inner_sum_weighted = 0.0
            outer_sum_weighted = 0.0
            for it in neighbor:
                if it in graph and it > id:
                    inner_sum_weighted = inner_sum_weighted + weight[id, it]
                    edge_in = edge_in + 1
                else:
                    outer_sum_weighted = outer_sum_weighted + weight[id, it]
                    edge_out = edge_out + 1
            weight_in = weight_in + inner_sum_weighted
            weight_out = weight_out + outer_sum_weighted
            if edge_in != 0:
               sum_up = weight_in / edge_in
            else:
               sum_up = 0.0
            if edge_out != 0:
                sum_down = weight_out / edge_out
            else:
                sum_down = 0.0
        if weight_in + weight_out > 0.0 and sum_down + sum_up > 0:
            score = sum_up / (sum_down + sum_up)
        else:
            score = 0.0
    else:
        score = 0.0
    return score
# ****************************************************************
def fitnessfunction(graph, relations, weights):
    densitys = density(graph, relations, weights)
    cohesiveness = Cohesiveness(graph, weights, relations)
    #modularitys = modularity(graph, relations, weights)
    AWMs = AWM(graph,relations,weights)
    score = densitys*max(cohesiveness,AWMs)
    #score = densitys *cohesiveness+AWMs
    #score = densitys*AWMs
    return score
# ****************************************************************
def Selectingseeds(id_label, relations, weights,ratio):
    seeds = id_label.keys()
    seedscore = {}
    averagescore = 0.0
    for ib in seeds:
        scoreib = sqrtdensity(relations[ib] + [ib], relations, weights)
        #scoreib = density(relations[ib] + [ib], relations, weights)
        seedscore[ib] = scoreib
        #averagescore = averagescore + scoreib
    #averagescore = averagescore / len(seeds)
    d2 = sorted(seedscore.items(), key=lambda seedscore: seedscore[1], reverse=True)
    num = ratio*len(seeds)
    Seeds = []
    count = 0
    for ih in d2:
        count = count + 1
        if count < num:
        #if ih[1] >= 0.0:
           Seeds.append(ih[0])
    return Seeds
# ****************************************************************
def Proteincores(Seeds,id_label, relations, relationsSL, gene_expressionfiles, weights, weight_ge,inflate):
    i = 0
    SL_dicts = {}
    SL_name = []
    for id in relationsSL:
        SL_features = relationsSL[id]
        for it in SL_features:
            if it not in SL_name:
                SL_name.append(it)
                SL_dicts[it] = i
                i = i + 1
    SL_codes = defaultdict(list)
    for iw in relationsSL:
        iw_relationsSL = relationsSL[iw]
        lists = []
        for iz in iw_relationsSL:
            if iz in SL_dicts:
                lists.append(SL_dicts[iz])
        SL_codes[iw] = lists

    j = 0
    proteincores = defaultdict(list)
    visited = []
    for id in Seeds:
      if id not in visited:
        id_seed = []
        id_seed.append(id)
        visited.append(id)
        id_SL = set(SL_codes[id])
        neighbors = relations[id]
        sl = 0
        ce = 0
        for it in neighbors:
            it_SL = set(SL_codes[it])
            if len(id_SL & it_SL) >= 1:
                sl = 1
            pcc_score = 0.0
            if len(gene_expressionfiles[id]) > 0 and len(gene_expressionfiles[it]) > 0:
                pcc_score = protein_protein_PCC(gene_expressionfiles[id], gene_expressionfiles[it])
            if pcc_score >= weight_ge:
                ce = 1
            if sl == 1 and ce == 1:
                if it not in id_seed:
                    id_seed.append(it)
                    visited.append(it)
        if len(id_seed) >= 2:
            proteincores[j] = id_seed
            j = j + 1
    MCL_cluters = mclcluster.mclclusters(id_label, relations, inflate, 100, weights)
    i = len(proteincores) + 1
    for id in MCL_cluters:
        proteincores[i] = MCL_cluters[id]
        i = i + 1
    proteincores = Redundancy_filtering(proteincores, 1.0)
    return proteincores

# ****************************************************************
def graphneighbors(graph, relations):
    neighbors = []
    for id in graph:
        neighbors_id = relations[id]
        for it in neighbors_id:
            if it not in neighbors and it not in graph:
                neighborsit = relations[it]
                if len(set(neighborsit) & set(graph)) >= 2:
                    neighbors.append(it)
    return neighbors
# ****************************************************************
def nodeconnectgraph(node, graph, relations, weights):
    connectsum = 0.0
    node_neighbors = relations[node]
    if len(node_neighbors) == 0:
        connectsum = 0.0
    else:
        for id in node_neighbors:
            if id in graph:
                connectsum = connectsum + weights[node, id]
        #connectsum = connectsum*connectsum /len(node_neighbors)*len(graph)
        connectsum = connectsum/ len(graph)
    return connectsum
# ****************************************************************
def choicenode(neighbors, graph, relations, weights):
    max_id = random.choice(neighbors)
    max_value = nodeconnectgraph(max_id, graph, relations, weights)
    for id in neighbors:
        temp = nodeconnectgraph(id, graph, relations, weights)
        if temp >= max_value:
            max_value = temp
            max_id = id
    return max_id
# ****************************************************************
def proteincomplexes(seeds, relations, weights):
    k = 1
    clusters = defaultdict(list)
    clusters_scores = {}
    for id in seeds:
        initialgraph = copy.deepcopy(seeds[id])
        #print "seeds[id]=====", seeds[id]
        mark = 1
        while mark:
            neighbors = graphneighbors(initialgraph, relations)
            if len(neighbors) == 0:
                break
            it_max = choicenode(neighbors, initialgraph, relations, weights)
            if fitnessfunction(initialgraph + [it_max], relations, weights) > fitnessfunction(initialgraph, relations,weights):
                initialgraph.append(it_max)
            else:
                mark = 0
        k_score = fitnessfunction(initialgraph, relations, weights)
        if len(initialgraph) >= 3 and k_score > 0.0:
            clusters[k] = initialgraph
            clusters_scores[k] = k_score
            k = k + 1
        #print "initialgraph1=", initialgraph
        #print "====================================!"
    return clusters

# ****************************************************************
def sort_complexes(seed):
    com = defaultdict(list)
    complexk = {}
    # print "seed=",seed
    for index in seed:
        complexk[index] = len(seed[index])
    dict = sorted(complexk.iteritems(), key=lambda d: d[1], reverse=True)
    # print "dict=",dict
    k = 0
    for indexk in dict:
        # print "indexk=",indexk
        ink = list(indexk)
        # print "ink[0]=",ink[0]
        com[k] = seed[ink[0]]
        # print "seed[ink[0]]",seed[ink[0]]
        k = k + 1
    # print "com=",com
    return com
# ****************************************************************
def remove_three_size(complexes):
    iy = 0
    PCs = defaultdict(list)
    a = set(complexes.iterkeys())
    for id in a:
        if len(complexes[id]) >= 3:
            PCs[iy] = complexes[id]
            iy = iy + 1
        else:
            continue
    return PCs
# ***************************************************************
def Redundancy_filtering(Core_dict,overlapscore):
    iy = 0
    PCs = defaultdict(list)
    for id in Core_dict:
        cluster = Core_dict[id]
        cluster_set = list(set(cluster))
        if len(cluster_set) >= 3:
            PCs[iy] = cluster_set
            iy = iy + 1
    com = defaultdict(list)
    complexk = {}
    # print "seed=",seed
    for index in PCs:
        cluster = PCs[index]
        complexk[index] = len(cluster)
    dict = sorted(complexk.items(), key=lambda d: d[1], reverse=True)
    k = 0
    for indexk in dict:
        #print "indexk=",indexk
        ink = indexk
        #print "ink[0]=",ink[0]
        cluster = PCs[ink[0]]
        #print "cluster =",cluster
        cluster.sort()
        com[k] = cluster
        # print "seed[ink[0]]",seed[ink[0]]
        k = k + 1

    proteincomplexes = com
    visit = []
    for i in range(len(proteincomplexes) - 1):
        if i not in visit:
           for j in range(i + 1, len(proteincomplexes) - 1):
             if j not in visit:
                set1 = set(proteincomplexes[i])
                set2 = set(proteincomplexes[j])
                score = Overlap_matchingscore(set1,set2)
                if score >= overlapscore:
                   visit.append(j)
    #print "visit=",visit
    wrq = defaultdict(list)
    for ib in proteincomplexes:
        #print "ib=",ib
        if len(proteincomplexes) >= 3 and ib not in visit:
            wrq[ib] = proteincomplexes[ib]
    wrq1 = defaultdict(list)
    ij = 0
    for id in wrq:
        cluster = wrq[id]
        cluster.sort()
        wrq1[ij] = cluster
        ij = ij + 1
    #print "***************************************************************"
    #for id in wrq1:
    #    print "wrq1[id]=",id,wrq1[id]
    return wrq1
#############################################################
def Overlap_matchingscore(Cluster_A,Cluster_B):
    Cluster_A = set(Cluster_A)
    Cluster_B = set(Cluster_B)
    overlap_set = Cluster_A & Cluster_B
    overlap_num = float(len(overlap_set))
    Cluster_A_size = float(len (Cluster_A))
    Cluster_B_size = float(len(Cluster_B))
    O_A_B = (overlap_num * overlap_num) / (Cluster_A_size * Cluster_B_size)
    return O_A_B
#############################################################
def CreateResultFile(seedt,id_protein,f ="Result.txt"):
    f = open(f,'w')
    k = 0
    for id in seedt:
        lists = seedt[id]
        if len(lists) < 3:
            continue
        else:
            k = k + 1
            s = str(k)
            for name in lists:
                s = s + " " + id_protein[name]
            f.write(s)
            f.write('\n')
    f.close()
# ****************************************************************
def Transformid_label(Proteincomplexes, id_label):
    Transformcomplexes = defaultdict(list)
    PCkeys1 = Proteincomplexes.keys()
    PCkeys = PCkeys1
    for id in PCkeys:
        currentcluster = []
        clusterid = Proteincomplexes[id]
        for it in clusterid:
            currentcluster.append(id_label[it])
        Transformcomplexes[id] = currentcluster
    return Transformcomplexes
# ****************************************************************
def fitness(Proteincomplexes, relations,Weights):
    fitnessssum = 0.0
    #unionset = set()
    for id in Proteincomplexes:
        clusterid = Proteincomplexes[id]
        #clusteridset = set(clusterid)
        #print "clusteridset =",clusteridset
        #unionset = unionset | clusteridset
        #print "clusterid =",clusterid
        #print "unionset =",unionset
        scoreid = fitnessfunction(clusterid, relations,Weights)
        fitnessssum = fitnessssum + scoreid
    #fitnessssum = fitnessssum*len(unionset) / len(Proteincomplexes)
    #fitnessssum = fitnessssum / len(Proteincomplexes)
    return fitnessssum
# ****************************************************************
def funccomplexes(GO_terms,label_id,lvl):
    #print "GO_terms=", GO_terms
    gene_func = list()
    for line in open(GO_terms, "r"):
        strs = line.upper().split('|')
        gene = strs[0].strip()
        func = strs[1].strip()
        if func.startswith('-'): continue
        gene_func.append((gene, func))
    #print "gene_func=",gene_func
    d_func_genes = dict()
    for gene, func in gene_func:
        #print "gene,func=",gene,func
        strs = func.split('.')
        if strs[0] in ('-', '99'): continue  # Group 99 is the unspecified class, so we ignore it
        fun_name = '.'.join(strs[:lvl])
        d_func_genes.setdefault(fun_name, set())
        d_func_genes[fun_name].add(gene)
    #print "d_func_genes=", d_func_genes
    functionalcomplexes = defaultdict(list)
    o = 1
    for id in d_func_genes:
        #print "d_func_genes[id]=",d_func_genes[id]
        cluster_id = d_func_genes[id]
        for ih in cluster_id:
            if ih in label_id:
                functionalcomplexes[o].append(label_id[ih])
        if len(functionalcomplexes[o]) >= 3:
            #print "functionalcomplexes[o]=", functionalcomplexes[o]
            o = o + 1
    #print "functionalcomplexes =", len(functionalcomplexes)
    return functionalcomplexes
# ****************************************************************
def Filteringcomplexes(Proteincomplexes,id_label,relationsGO):
    i = 0
    Finallycomplexes = defaultdict(list)
    for id in Proteincomplexes:
        leftcluster = []
        GOlist = []
        clusterid = Proteincomplexes[id]
        for it in clusterid:
            name = id_label[it]
            GOlists_name = relationsGO[name]
            GOlist = GOlist + GOlists_name
        #print "GOlist=",GOlist
        GOtermscount = {}
        for io in GOlist:
            GOtermscount[io] = GOlist.count(io)
        d2 = sorted(GOtermscount.items(), key=lambda GOtermscount: GOtermscount[1], reverse=True)
        #print "d2 =",d2
        GOtermmax = d2[0]
        #print "len(clusterid),GOtermmax =",len(clusterid),GOtermmax[0],GOtermmax[1]
        for it in clusterid:
            name = id_label[it]
            GOlists_name = relationsGO[name]
            if GOtermmax[0] in GOlists_name:
                leftcluster.append(it)
        #print "leftcluster=",leftcluster
        if len(leftcluster) >= 3:
           Finallycomplexes[i] = leftcluster
           i = i + 1
    return Finallycomplexes
# ****************************************************************

def main(weight_ge,inflate,ratio,lists,relations, label_id, id_label,weight):
    #print "weight_ge,inflate,ratio,os=",weight_ge,inflate,ratio,os
    #print "***************************************************************"
    GO_url = '..\datasets/Go_slim_mapping1.txt'
    weight_GO, relationsGO = GO_slims(GO_url, relations, label_id)
    #print "relationsGO=",relationsGO
    # print "***************************************************************"
    SL_url = lists + 'Subcellular_localization.txt'
    weight_SL, relationsSL = subcellular_localization(SL_url, relations, id_label)
    # print "relationsSL=",relationsSL
    # print "***************************************************************"
    GE_url = lists + 'gene_expression_data.txt'
    GE_weight, gene_expressionfiles = gene_expression_weight(relations, label_id, GE_url)
    #weight_ge = 0.8
    #inflate = 1.0
    # print "GE_weight=", GE_weight
    #weightTS = CN(id_label, relations)
    # print "***************************************************************"
    #weights = (weight_SL + weight_GO + GE_weight + weightTS) / 4
    #weights = (weight_GO + weightTS) / 2
    weights = weight
    #weights = (weight + weight_GO) / 2
    #print ("weights =", weights)
    #print "***************************************************************"
    Seeds = Selectingseeds(id_label, relations, weights,ratio)
    # ****************************************************************
    complex_cores = Proteincores(Seeds,id_label, relations, relationsSL, gene_expressionfiles, weights, weight_ge,inflate)
    #print ("complex_cores =",len(complex_cores))
    # print "***************************************************************"
    Proteincomplexes = proteincomplexes(complex_cores,relations,weights)
    #print ("permanentcomplexes ==", len(Proteincomplexes))
    # print "***************************************************************"
    Proteincomplexes = Filteringcomplexes(Proteincomplexes, id_label, relationsGO)
    Proteincomplexes = Redundancy_filtering(Proteincomplexes,1.0)
    #print "Proteincomplex =", len(Proteincomplexes)
    #print "***************************************************************"
    fitnessscore = fitness(Proteincomplexes, relations,weights)
    #print "***************************************************************"
    return fitnessscore,Proteincomplexes
