import time
from collections import defaultdict
from numpy.matlib import zeros
import math
import random
import string
import numpy as np
import mclcluster
import copy

# ***************************************************************
def multipl(a,b):
    sumofab=0.0
    for i in range(len(a)):
        temp=a[i]*b[i]
        sumofab+=temp
    return sumofab
# ***************************************************************
def protein_protein_PCC(node1, node2):
    timenode1 = np.array(node1)
    # print "timenode1 =",timenode1
    timenode2 = np.array(node2)
    # print "timenode2 =", timenode2
    n = len(timenode1)
    sumnode1 = sum(timenode1)
    sumnode2 = sum(timenode2)
    sumofxy = multipl(timenode1,timenode2)
    sumofx2 = sum([pow(i,2) for i in timenode1])
    sumofy2 = sum([pow(j,2) for j in timenode2])
    num = sumofxy-(float(sumnode1)*float(sumnode2)/n)
    corrcoef = math.sqrt((sumofx2-float(sumnode1**2)/n)*(sumofy2-float(sumnode2**2)/n))
    pcc = float(num)/corrcoef
    pcc = float(pcc + 1.0) / 2
    return pcc

# ****************************************************************
def sqrtdensity(graph, relations, weights):
    # print "graph=",graph
    sum_weight = 0.0
    if len(graph) >= 2:
        for id in graph:
            neighbors = relations[id]
            for it in neighbors:
                # print "id,it=",id,it
                if it > id and it in graph:
                    sum_weight = sum_weight + weights[id, it]
        density = 2 * sum_weight * math.sqrt(len(graph)) / (len(graph) * (len(graph) - 1))
    else:
        density = 0.0
    return density
# ****************************************************************
def density(graph, relations, weights):
    # print "graph=",graph
    sum_weight = 0.0
    if len(graph) >= 2:
        for id in graph:
            neighbors = relations[id]
            for it in neighbors:
                # print "id,it=",id,it
                if it > id and it in graph:
                    sum_weight = sum_weight + weights[id, it]
        density = 2 * sum_weight / (len(graph) * (len(graph) - 1))
    else:
        density = 0.0
    return density
# ****************************************************************
def Cohesiveness(graph, weights, relations):
    sum_weight = 0.0
    node_dict = {}
    k = 1
    for id in graph:
        node_dict[k] = id
        k = k + 1
    for it in node_dict:
        for ih in node_dict:
            if ih > it and weights[node_dict[it], node_dict[ih]] > 0.0:
                sum_weight = sum_weight + weights[node_dict[it], node_dict[ih]]
    sum_out_weight = 0.0
    for id1 in node_dict:
        neighbors = relations[node_dict[id1]]
        for iw in neighbors:
            if iw not in graph:
                sum_out_weight = sum_out_weight + weights[node_dict[id1], iw]
    modularitys = 0.0
    if (sum_weight + sum_out_weight) == 0.0 or len(graph) <= 2:
        modularitys = 0.0
    else:
        weightin = sum_weight
        weightout = sum_out_weight
        modularitys = weightin / (weightin + weightout)
    return modularitys
# ****************************************************************
def modularity(graph, relations, weight):
    sum_weight = 0.0
    node_dict = {}
    k = 1
    for id in graph:
        node_dict[k] = id
        k = k + 1
    for it in node_dict:
        for ih in node_dict:
            if ih <= it:
                continue
            else:
                if weight[node_dict[it], node_dict[ih]] > 0.0:
                    sum_weight = sum_weight + weight[node_dict[it], node_dict[ih]]
    sum_out_weight = 0.0
    neighbors_nodes = []
    for id1 in node_dict:
        neighbors = relations[node_dict[id1]]
        for iw in neighbors:
            if iw not in graph:
                sum_out_weight = sum_out_weight + weight[node_dict[id1], iw]
                if iw not in neighbors_nodes:
                   neighbors_nodes.append(iw)
            else:
                continue
    modularitys = 0.0
    if len(neighbors_nodes) < 1 or len(graph) <= 2:
        modularitys = 0.0
    else:
        avgdensity = 2 * sum_weight / len(graph)
        avg_out_weight = sum_out_weight / len(neighbors_nodes)
        modularitys = avgdensity / (avgdensity + avg_out_weight)
    return modularitys
# ****************************************************************
def densitymodularitys(graph, relations, weight):
    sum_weight = 0.0
    node_dict = {}
    k = 1
    for id in graph:
        node_dict[k] = id
        k = k + 1
    for it in node_dict:
        for ih in node_dict:
            if ih > it and weight[node_dict[it], node_dict[ih]] > 0.0:
               sum_weight = sum_weight + weight[node_dict[it], node_dict[ih]]
    sum_out_weight = 0.0
    neighbors_nodes = []
    for id1 in node_dict:
        neighbors = relations[node_dict[id1]]
        for iw in neighbors:
            if iw not in graph:
                sum_out_weight = sum_out_weight + weight[node_dict[id1], iw]
                if iw not in neighbors_nodes:
                   neighbors_nodes.append(iw)

    if len(neighbors_nodes) < 1 or len(graph) <= 2:
        modularitys = 0.0
    else:
        modularitys = (2 * sum_weight-sum_out_weight) / len(graph)
    return modularitys
# ****************************************************************
def AWM(graph,relations,weight):
    if len(graph) >= 2:
        weight_in = 0.0
        weight_out = 0.0
        edge_in = 0.0
        edge_out = 0.0
        for id in graph:
            neighbor = relations[id]
            inner_sum_weighted = 0.0
            outer_sum_weighted = 0.0
            for it in neighbor:
                if it in graph and it > id:
                    inner_sum_weighted = inner_sum_weighted + weight[id, it]
                    edge_in = edge_in + 1
                else:
                    outer_sum_weighted = outer_sum_weighted + weight[id, it]
                    edge_out = edge_out + 1
            weight_in = weight_in + inner_sum_weighted
            weight_out = weight_out + outer_sum_weighted
            if edge_in != 0:
               sum_up = weight_in / edge_in
            else:
               sum_up = 0.0
            if edge_out != 0:
                sum_down = weight_out / edge_out
            else:
                sum_down = 0.0
        if weight_in + weight_out > 0.0 and sum_down + sum_up > 0:
            score = sum_up / (sum_down + sum_up)
        else:
            score = 0.0
    else:
        score = 0.0
    return score
# ****************************************************************
def fitnessfunction(graph, relations, weights):
    densitys = density(graph, relations, weights)
    cohesiveness = Cohesiveness(graph, weights, relations)
    #densitymodularity = densitymodularitys(graph, relations, weights)
    #print("densitymodularity =",densitymodularity)
    AWMs = AWM(graph,relations,weights)
    #score = densitys*max(cohesiveness,AWMs)
    score = densitys+cohesiveness+AWMs
    #score = max(densitys, cohesiveness, AWMs)
    #score = cohesiveness
    return score
# ****************************************************************
def Selectingseeds(id_label, relations, weights,ratio):
    seeds = id_label.keys()
    seedscore = {}
    for ib in seeds:
        scoreib = sqrtdensity(relations[ib] + [ib], relations, weights)
        seedscore[ib] = scoreib
    d2 = sorted(seedscore.items(), key=lambda seedscore: seedscore[1], reverse=True)
    num = ratio*len(seeds)
    Seeds = []
    count = 0
    for ih in d2:
        count = count + 1
        if count < num:
           Seeds.append(ih[0])
    return Seeds
# ****************************************************************
def Proteincores(Seeds,id_label, relations,SL_codes, gene_expressionfiles, weights, weight_ge,inflate):
    j = 0
    proteincores = defaultdict(list)
    visited = []
    for id in Seeds:
      if id not in visited:
        id_seed = []
        id_seed.append(id)
        visited.append(id)
        id_SL = set(SL_codes[id])
        neighbors = relations[id]
        sl = 0
        ce = 0
        for it in neighbors:
            it_SL = set(SL_codes[it])
            if len(id_SL & it_SL) >= 1:
                sl = 1
            pcc_score = 0.0
            if len(gene_expressionfiles[id]) > 0 and len(gene_expressionfiles[it]) > 0:
                pcc_score = protein_protein_PCC(gene_expressionfiles[id], gene_expressionfiles[it])
            if pcc_score >= weight_ge:
                ce = 1
            if sl == 1 and ce == 1:
                if it not in id_seed:
                    id_seed.append(it)
                    visited.append(it)
        if len(id_seed) >= 2:
            proteincores[j] = id_seed
            j = j + 1
    MCL_cluters = mclcluster.mclclusters(id_label, relations, inflate, 100, weights)
    i = len(proteincores) + 1
    for id in MCL_cluters:
        proteincores[i] = MCL_cluters[id]
        i = i + 1
    proteincores = Redundancy_filtering(proteincores, 1.0)
    return proteincores

# ****************************************************************
def graphneighbors(graph, relations):
    neighbors = []
    for id in graph:
        neighbors_id = relations[id]
        for it in neighbors_id:
            if it not in neighbors and it not in graph:
                neighborsit = relations[it]
                if len(set(neighborsit) & set(graph)) >= (1/3)*len(graph):
                #if len(set(neighborsit) & set(graph)) >= 1:
                   neighbors.append(it)
    return neighbors
# ****************************************************************
def addconnectgraph(node, graph, relations, weights):
    connectsum = 0.0
    node_neighbors = relations[node]
    if len(node_neighbors) == 0:
        connectsum = 0.0
    else:
        for id in node_neighbors:
            if id in graph:
                connectsum = connectsum + weights[node, id]
        #connectsum = connectsum*connectsum /len(node_neighbors)*len(graph)
        connectsum = connectsum / (len(graph))
        #connectsum = connectsum/ (len(graph)*len(relations[id]))
    return connectsum
# ****************************************************************
def addnode(neighbors, graph, relations, weights):
    max_id = random.choice(neighbors)
    max_value = addconnectgraph(max_id, graph, relations, weights)
    #max_value = fitnessfunction(graph + [max_id], relations, weights)+max_value0
    for id in neighbors:
        temp = addconnectgraph(id, graph, relations, weights)
        #temp = fitnessfunction(graph + [id], relations, weights)+temp0
        if temp >= max_value:
            max_value = temp
            max_id = id
    return max_id,max_value
# ****************************************************************
def delconnectgraph(node, graph, relations, weights):
    initialgraph = copy.deepcopy(graph)
    initialgraph.remove(node)
    connectsum = 0.0
    node_neighbors = relations[node]
    if len(node_neighbors) == 0:
        connectsum = 0.0
    else:
        for id in node_neighbors:
            if id in initialgraph:
                connectsum = connectsum + weights[node, id]
        #connectsum = connectsum*connectsum /len(node_neighbors)*len(graph)
        connectsum = connectsum / (len(graph))
        #connectsum = connectsum / (len(graph) * len(relations[id]))
    return connectsum
# ****************************************************************
def deletenode(graph, relations, weights):
    min_id = random.choice(graph)
    min_value = delconnectgraph(min_id, graph, relations, weights)
    #max_value = fitnessfunction(graph + [max_id], relations, weights)+max_value0
    for id in graph:
        temp = delconnectgraph(id, graph, relations, weights)
        #temp = fitnessfunction(graph + [id], relations, weights)+temp0
        if temp < min_value:
            min_value = temp
            min_id = id
    return min_id,min_value
# ****************************************************************
def proteincomplexes(seeds, relations, weights):
    k = 1
    clusters = defaultdict(list)
    clusters_scores = {}
    for id in seeds:
        initialgraph = copy.deepcopy(seeds[id])
        mark = 1
        count = 0
        neighbors = graphneighbors(initialgraph, relations)
        while mark:
            #add nodes:
            initialgraph1 = copy.deepcopy(initialgraph)
            mark0 = 1
            while len(neighbors) >= 2 and mark0 == 1:
               it_max,it_value = addnode(neighbors, initialgraph, relations, weights)
               if fitnessfunction(initialgraph+[it_max], relations,weights) > fitnessfunction(initialgraph, relations,weights):
                  initialgraph.append(it_max)
                  neighbors.remove(it_max)
               else:
                   mark0 = 0
            # del nodes:
            mark1 = 1
            while len(initialgraph) >= 4 and mark1 == 1:
               it_min,it_value = deletenode(initialgraph, relations, weights)
               tempgraph = copy.deepcopy(initialgraph)
               tempgraph.remove(it_min)
               if fitnessfunction(tempgraph, relations,weights) > fitnessfunction(initialgraph, relations,weights):
                  initialgraph.remove(it_min)
               else:
                   mark1 = 0
            count = count + 1
            if count >= 2 or set(initialgraph1) == set(initialgraph):
                #print("count=",count)
                mark = 0
        k_score = fitnessfunction(initialgraph, relations, weights)
        #print("initialgraph=",initialgraph)
        #print("===============================!")
        if len(initialgraph) >= 3 and k_score > 0.0:
            clusters[k] = initialgraph
            clusters_scores[k] = k_score
            k = k + 1
    return clusters

# ***************************************************************
def Redundancy_filtering(Core_dict,overlapscore):
    iy = 0
    PCs = defaultdict(list)
    for id in Core_dict:
        cluster = Core_dict[id]
        cluster_set = list(set(cluster))
        if len(cluster_set) >= 3:
            PCs[iy] = cluster_set
            iy = iy + 1
    com = defaultdict(list)
    complexk = {}
    # print "seed=",seed
    for index in PCs:
        cluster = PCs[index]
        complexk[index] = len(cluster)
    dict = sorted(complexk.items(), key=lambda d: d[1], reverse=True)
    k = 0
    for indexk in dict:
        #print "indexk=",indexk
        ink = indexk
        #print "ink[0]=",ink[0]
        cluster = PCs[ink[0]]
        #print "cluster =",cluster
        cluster.sort()
        com[k] = cluster
        # print "seed[ink[0]]",seed[ink[0]]
        k = k + 1

    proteincomplexes = com
    visit = []
    for i in range(len(proteincomplexes) - 1):
        if i not in visit:
           for j in range(i + 1, len(proteincomplexes) - 1):
             if j not in visit:
                set1 = set(proteincomplexes[i])
                set2 = set(proteincomplexes[j])
                score = Overlap_matchingscore(set1,set2)
                if score >= overlapscore:
                   visit.append(j)
    #print "visit=",visit
    wrq = defaultdict(list)
    for ib in proteincomplexes:
        #print "ib=",ib
        if len(proteincomplexes) >= 3 and ib not in visit:
            wrq[ib] = proteincomplexes[ib]
    wrq1 = defaultdict(list)
    ij = 0
    for id in wrq:
        cluster = wrq[id]
        cluster.sort()
        wrq1[ij] = cluster
        ij = ij + 1
    return wrq1
# ****************************************************************
def Overlap_matchingscore(Cluster_A,Cluster_B):
    Cluster_A = set(Cluster_A)
    Cluster_B = set(Cluster_B)
    overlap_set = Cluster_A & Cluster_B
    overlap_num = float(len(overlap_set))
    Cluster_A_size = float(len (Cluster_A))
    Cluster_B_size = float(len(Cluster_B))
    O_A_B = (overlap_num * overlap_num) / (Cluster_A_size * Cluster_B_size)
    return O_A_B
# ****************************************************************
def Transformid_label(Proteincomplexes, id_label):
    Transformcomplexes = defaultdict(list)
    PCkeys1 = Proteincomplexes.keys()
    PCkeys = PCkeys1
    for id in PCkeys:
        currentcluster = []
        clusterid = Proteincomplexes[id]
        for it in clusterid:
            currentcluster.append(id_label[it])
        Transformcomplexes[id] = currentcluster
    return Transformcomplexes
# ****************************************************************
def fitness(Proteincomplexes, relations,Weights):
    fitnessssum = 0.0
    for id in Proteincomplexes:
        clusterid = Proteincomplexes[id]
        scoreid = fitnessfunction(clusterid, relations,Weights)
        fitnessssum = fitnessssum + scoreid
    #fitnessssum = fitnessssum*len(unionset) / len(Proteincomplexes)
    #fitnessssum = fitnessssum / len(Proteincomplexes)
    return fitnessssum
# ****************************************************************
def Filteringcomplexes(Proteincomplexes,id_label,relationsGO):
    i = 0
    Finallycomplexes = defaultdict(list)
    for id in Proteincomplexes:
        leftcluster = []
        GOlist = []
        clusterid = Proteincomplexes[id]
        for it in clusterid:
            name = id_label[it]
            GOlists_name = relationsGO[name]
            GOlist = GOlist + GOlists_name
        #print("GOlist=",GOlist)
        GOlist1 = copy.deepcopy(GOlist)

        GOtermscount = {}
        for io in GOlist1:
            GOtermscount[io] = GOlist.count(io)
            #print("GOtermscount[io] =",GOtermscount[io])
        #print(" GOtermscount=", GOtermscount)
        #d2 = sorted(GOtermscount.items(), key=lambda GOtermscount: GOtermscount[1], reverse=True)
        #print("GOtermscount=", len(GOtermscount), GOtermscount)
        #print("type(maximum)=", type(maximum))
        if len(GOtermscount) == 0:
            leftcluster = clusterid
        else:
            maximum = max(GOtermscount, key=GOtermscount.get)
            #print("maximum =", maximum)
            for it in clusterid:
                name = id_label[it]
                GOlists_name = relationsGO[name]
                if maximum in GOlists_name:
                    leftcluster.append(it)
        #print "leftcluster=",leftcluster
        if len(leftcluster) >= 3:
           Finallycomplexes[i] = leftcluster
           i = i + 1
    return Finallycomplexes
# ****************************************************************

def main(weight_ge,inflate,ratio,relations,id_label,weight,relationsGO,SL_codes,gene_expressionfiles):
    weights = weight
    #print "***************************************************************"
    Seeds = Selectingseeds(id_label, relations, weights,ratio)
    #print "***************************************************************"
    complex_cores = Proteincores(Seeds,id_label, relations,SL_codes, gene_expressionfiles, weights, weight_ge,inflate)
    #print ("complex_cores =",len(complex_cores))
    # print "***************************************************************"
    Proteincomplexes = proteincomplexes(complex_cores,relations,weights)
    #print ("permanentcomplexes ==", len(Proteincomplexes))
    # print "***************************************************************"
    Proteincomplexes = Filteringcomplexes(Proteincomplexes, id_label, relationsGO)
    # print "***************************************************************"
    Proteincomplexes = Redundancy_filtering(Proteincomplexes,1.0)
    #print "Proteincomplex =", len(Proteincomplexes)
    #print "***************************************************************"
    fitnessscore = fitness(Proteincomplexes, relations,weights)
    #print "***************************************************************"
    return fitnessscore,Proteincomplexes
    #print "***************************************************************"