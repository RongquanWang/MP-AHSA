import sklearn
import sklearn.metrics.matthews_corrcoef
from collections import defaultdict
from numpy import *
import mwmatching

###########################################################################
def read_complex1(complex):
    complexes = defaultdict(list)
    read_point = open(complex,"r");
    com = defaultdict(list)
    k = 1
    averagesize = 0.0
    for line in read_point.readlines():
        line_interaction = line.split()
        complexes = line_interaction[1:]
        #print("complexes =",len(complexes))
        averagesize = averagesize+len(complexes)
        com[k] = complexes
        k = k + 1
    print("averagesize =",averagesize/len(com))
    return com
###########################################################################
def strtolist(com):
    for id in com:
        #print "com[id]=",com[id].split()
        com[id] = com[id].split()
    #print "com=",com
    return com
###########################################################################
def refilter_complex(complex):
    for id in complex:
        print (id)
        print(complex[id])
        complex[id].remove(str(id))
        #print complex[id]
    #print complex
    return complex
###########################################################################
def NA(a,b):
    set_a = set(a)
    set_b = set(b)
    #print "set_a=",set_a
    #print "set_b=",set_b
    comm = float(len(set_a & set_b))
    #print "set_a & set_b=",set_a & set_b
    union = len(set_a) * len(set_b)
    #print "union =",union
    return (comm * comm) / union
###########################################################################
def Matthews(reference_complexes1,predicted_complexes1,a):
    length = len(reference_complexes1)
    num = 0.0
    for id in reference_complexes1:
        # print "id=",id
        w = 0.0
        for it in predicted_complexes1:
            # print it
            # print "it=", predicted[it]
            # if it == 555:
            #    continue
            w = NA(reference_complexes1[id], predicted_complexes1[it])
            if w >= a:
                num = num + 1
                # print "w=", w
                break
        # print "=========================="
    TP = float(num) / length
    FN = (length-num)/length

    length1 = len(predicted_complexes1)
    # print "length=",length
    num1 = 0.0
    for id1 in predicted_complexes1:
        w = 0.0
        for it1 in reference_complexes1:
            # print "it=", it
            w = NA(reference_complexes1[it1], predicted_complexes1[id1])
            if w >= a:
                num1 = num1+ 1
                break
    precision = float(num1) / length1
    FP = length1 - float(num1)
    print ("FP =",FP)
    TN = precision
    numerator = (TP * TN) - (FP * FN)  # 马修斯相关系数公式分子部分
    denominator = sqrt((TP + FP) * (TP + FN) * (TN + FP) * (TN + FN))  # 马修斯相关系数公式分母部分
    matthews = numerator / denominator
    print("matthews=",matthews)
    return matthews
###########################################################################
def canonical_protein_name(name):
    """Returns the canonical name of a protein by performing a few simple
    transformations on the name."""
    return name.strip().upper()
###########################################################################
def read_complexes(fname, known_proteins=None, strictness=0.5,min_size=3, max_size=1000):
        result = []
        for line in open(fname):
            ps = set(canonical_protein_name(x) for x in line.strip().split() if x)
            if known_proteins is not None:
                isect = ps.intersection(known_proteins)
                if len(isect) < max(min_size, len(ps) * strictness):
                    continue
                if len(isect) > max_size:
                    continue
                ps = isect
            result.append(ps)

        to_delete = set()
        for idx, cluster in enumerate(result):
            for idx2, cluster2 in enumerate(result):
                if idx == idx2 or idx2 in to_delete:
                    continue
                if cluster == cluster2:
                    to_delete.add(idx2)

        result = [r for i, r in enumerate(result) if i not in to_delete]
        return result
###########################################################################
def read_network(fname):
        known_proteins = set()
        for line in open(fname):
            parts = [canonical_protein_name(part) for part in line.strip().split()
                    if not is_numeric(part)]
            known_proteins.update(parts)
        return known_proteins
###########################################################################
def justcount(one_data):
    del_just = False
    count = 0.0
    for i in one_data:
        # print "id[i]=",id[i]
        if one_data[i] == 0.0:
            count = count + 1
    # print count,len(id)
    if count / len(one_data) >= 0.8:
        del_just = True
    return del_just
###########################################################################
def is_numeric(x):
    """Returns whether the given string can be interpreted as a number."""
    try:
        float(x)
        return True
    except:
        return False
###########################################################################
def read_complexesp(fname):
        result = []
        for line in open(fname):
            line_1 = line.split()
            complexes = set(line_1[1:])
            #print("line=",complexes)
            result.append(complexes)

        to_delete = set()
        for idx, cluster in enumerate(result):
            for idx2, cluster2 in enumerate(result):
                if idx == idx2 or idx2 in to_delete:
                    continue
                if cluster == cluster2:
                    to_delete.add(idx2)

        result = [r for i, r in enumerate(result) if i not in to_delete]
        return result
###########################################################################



def main():
    dataset = 'CollinsW'
    # dataset = 'GavinW'
    # dataset = 'KroganW'
    dataset = 'DIP_PPIW'
    # dataset = 'BiogridW'
    dataset = 'StringW'
    ################################################################
    filename = '../datasets/' + dataset + '.txt'
    #################################################################
    mark = 2
    predicted_complexes = '..\Metrics\MP-AHSA_' + dataset + '.txt'
    predicted_complexes = '..\Metrics\MP-AHSA_StringW0.56.1.35.0.97.txt'
    # predicted_complexes ='C:/Users\WRQ-PC\Desktop\manuscripts\BMC Bioinformatics\String\PEWCC_String.txt'
    ################################################################
    reference_complexes = '../datasets/standardcomplexes' + str(mark) + '.txt'
    ################################################################
    predicted_complexes1 = read_complex1(predicted_complexes)
    #print("predicted_complexes1=",predicted_complexes1)
    ################################################################
    reference_complexes1 = read_complex1(reference_complexes)
    #print("reference_complexes1=",reference_complexes1)
    ###############################################################
    known_proteins = read_network(filename)
    reference_complexes_N = read_complexes(reference_complexes, known_proteins)
    predicted_complexes_N = read_complexesp(predicted_complexes)
    print("reference_complexes_N=", reference_complexes_N)
    print("predicted_complexes_N=", predicted_complexes_N)
    ################################################################
    a = 0.20
    f_measure, recall, precision = Matthews(reference_complexes1, predicted_complexes1, a)
    # print "=====================================================!"
    print(len(predicted_complexes1))

main()