from PIL import Image,ImageDraw,ImageFont
import matplotlib.pyplot as plt

_,axes = plt.subplots(1,1,figsize = (30,30))
imagename = "(a) 148th standard protein complexes 1"
img = Image.open("C:/Users\WRQ-PC\Desktop\manuscripts\BMC Bioinformatics\Casestudy/"+imagename+".jpg")
#axes[0].imshow(img)
#axes[0].set_title("original")

draw = ImageDraw.Draw(img)
font = ImageFont.truetype("micross.ttf",45)
draw.text((10,10),"hello",font = font)

#axes[0].imshow(img)
#axes[0].set_title(imagename)

plt.imshow(img)
plt.show()
