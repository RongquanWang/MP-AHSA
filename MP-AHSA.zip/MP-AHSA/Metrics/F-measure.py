from __future__ import division
from collections import defaultdict
from mwmatching import maxWeightMatching
import string
import math

###########################################################################
def read_complex1(complex):
    complexes = defaultdict(list)
    read_point = open(complex,"r");
    com = defaultdict(list)
    k = 1
    for line in read_point.readlines():
        line_interaction = string.split(line,"\t")
        #print "line_interaction =",line_interaction
        complexes = line_interaction[0].strip()
        com[k] = complexes
        k = k + 1
    return com
###########################################################################
def strtolist(com):
    for id in com:
        #print "com[id]=",com[id].split()
        com[id] = com[id].split()
    #print "com=",com
    return com
###########################################################################
def refilter_complex(complex):
    for id in complex:
        #print id
        complex[id].remove(str(id))
        #print complex[id]
    #print complex
    return complex
###########################################################################
def NA(a,b):
    set_a = set(a)
    set_b = set(b)
    #print "set_a=",set_a
    #print "set_b=",set_b
    comm = float(len(set_a & set_b))
    #print "set_a & set_b=",set_a & set_b
    union = len(set_a) * len(set_b)
    #print "union =",union
    return (comm * comm) / union
###########################################################################
def Recall(reference,predicted,a):
    length = len(reference)
    num = 0.0
    for id in reference:
        #print "id=",id
        w = 0.0
        for it in predicted:
            #print it
            #print "it=", predicted[it]
            #if it == 555:
            #    continue
            w = NA(reference[id],predicted[it])
            if w >= a:
                num = num + 1
                #print "w=", w
                break
            else:
                continue
        #print "=========================="
    recall = num / length
    #print "recall=",recall
    return recall
###########################################################################
def Precision(reference,predicted,a):
    length = len(predicted)
    #print "length=",length
    num = 0.0
    averagesize = 0.0
    for id in predicted:
        #print "id=",id
        w = 0.0
        #if id ==555:
        #    continue
        averagesize = averagesize +len(predicted[id])
        for it in reference:
            #print "it=", it
            w = NA(reference[it],predicted[id])
            if w >= a:
                num = num + 1
                #if w == 1.0:
                    #print "id=",id
                    #print "reference[it]=",reference[it]
                    #print "predicted[id]=",predicted[id]
                    #print "============================================================"
                #print "w=", w
                break
            else:
                continue
        #print "=========================="
    #print num,length
    averagesize = averagesize /length
    precision = float(num) / length
    #print "precision =", precision
    return precision,averagesize
###########################################################################
def F_measure(reference_complexes1,predicted_complexes1,a):
    recall = Recall(reference_complexes1,predicted_complexes1,a)
    #print "recall=",recall
    precision,averagesize = Precision(reference_complexes1,predicted_complexes1,a)
    #print "precision=",precision
    f_measure = (2*recall*precision) / (precision + recall)
    #print "F-measure=",f_measure
    return f_measure,recall,precision,averagesize
###########################################################################
def Coverage(reference,predict):
    score = 0.0
    top = 0.0
    down = 0.0
    for i in reference:
        number_i = set(reference[i])
        max_com = 0.0
        for j in predict:
            number_j = set(predict[j])
            common_ij = number_i & number_j
            if len(common_ij) > max_com:
                max_com = len(common_ij)
            else:
                continue
        #print "max_com=",max_com
        top = top + float(max_com)
        down = down + float(len(reference[i]))
    score = top / down
    #print "score=",score
    return score
###########################################################################
def T_ij(prediction,reference):
    T_ij = len(set(prediction) & set(reference))
    return T_ij
###########################################################################
def Sep_ij(Ts,i,j,reference_complex,predicted_complex):
    top = Ts*Ts
    T_nj = 0.0
    #print "top=",top
    for id in reference_complex:
        predicted_complex1 = predicted_complex[j]
        #print "predicted_complex1=", predicted_complex1
        T = T_ij(predicted_complex1,reference_complex[id])
        T_nj = T_nj + T
    #print "T_nj=",T_nj
    #print "******************************"
    T_im =0.0
    for it in predicted_complex:
        reference_complex1 = reference_complex[i]
        #print "reference_complex1=",reference_complex1
        T1 = T_ij(reference_complex1,predicted_complex[it])
        T_im = T_im + T1
    #print "T_im=", T_im
    #print "******************************"
    down = T_nj*T_im
    return  top/ down
###########################################################################
def Sep_g(reference_complexes,predicted_complexes):
    Sep_g = 0.0
    sep_sum =0.0
    #print "predict_complexes=",predicted_complexes
    #print "reference_complexes=",reference_complexes
    for i_n in reference_complexes:
        for j_m in predicted_complexes:
            Ts = T_ij(predicted_complexes[j_m],reference_complexes[i_n])
            #print "Ts=", Ts
            if Ts == 0:
                Sep_ijs = 0.0
            else:
                Sep_ijs = Sep_ij(Ts,i_n,j_m,reference_complexes,predicted_complexes)
            sep_sum = sep_sum + Sep_ijs
    Sep_g = sep_sum / len(reference_complexes)
    #print "Sep_g=",Sep_g
    return Sep_g
###########################################################################
def Sep_p(reference_complexes,predicted_complexes):
    Sep_p = 0.0
    sep_sum =0.0
    #print "predict_complexes=",predicted_complexes
    #print "reference_complexes=",reference_complexes
    for j_m in predicted_complexes:
        for i_n in reference_complexes:
            Ts = T_ij(predicted_complexes[j_m],reference_complexes[i_n])
            #print "Ts=", Ts
            if Ts == 0:
                Sep_ijs = 0.0
            else:
                Sep_ijs = Sep_ij(Ts,i_n,j_m,reference_complexes,predicted_complexes)
            sep_sum = sep_sum + Sep_ijs
    Sep_p = sep_sum / len(predicted_complexes)
    #print "Sep_p=",Sep_p
    return Sep_p
###########################################################################
def Sep(Sep_g,Sep_p):
    sep = Sep_g * Sep_p
    #print "Sep =",math.sqrt(sep)
    #print "************************"
    return math.sqrt(sep)
###########################################################################
def matching_score(set1, set2):
    """Calculates the matching score between two sets (e.g., a cluster and a complex)
    using the approach of Bader et al, 2001"""
    return len(set1.intersection(set2))**2 / (float(len(set1)) * len(set2))
###########################################################################
def accuracy(reference, predicted):
    return (clusteringwise_sensitivity(reference, predicted) * \
            positive_predictive_value(reference, predicted)) ** 0.5
###########################################################################
def clusteringwise_sensitivity(reference, predicted):
    num, den = 0., 0.
    for complex in reference:
        den += len(complex)
        num += max(len(complex.intersection(cluster)) for cluster in predicted)
    if den == 0.:
        return 0.
    return num / den
###########################################################################
def clusteringwise_separation(reference, predicted):
    intersections = {}
    marginal_sums = [0.] * len(predicted), [0.] * len(reference)
    for i, cluster in enumerate(predicted):
        for j, complex in enumerate(reference):
            isect = len(cluster.intersection(complex))
            if isect > 0:
                intersections[i, j] = isect
            marginal_sums[0][i] += isect
            marginal_sums[1][j] += isect

    separations_complex = [0.] * len(reference)
    separations_cluster = [0.] * len(predicted)
    for i, cluster in enumerate(predicted):
        s = marginal_sums[0][i]
        for j, complex in enumerate(reference):
            isect = intersections.get((i, j), 0)
            if isect == 0:
                continue
            val = float(isect * isect) / (s * marginal_sums[1][j])
            separations_complex[j] += val
            separations_cluster[i] += val

    avg_sep_complex = sum(separations_complex) / len(separations_complex)
    avg_sep_cluster = sum(separations_cluster) / len(separations_cluster)
    return (avg_sep_complex * avg_sep_cluster) ** 0.5
###########################################################################
def fraction_matched(reference,predicted,score_threshold=0.20):
    result = 0
    for id1, c1 in enumerate(reference):
        for id2, c2 in enumerate(predicted):
            score = matching_score(c1, c2)
            if score > score_threshold:
                result += 1
                break
    return result / len(reference)
###########################################################################
def maximum_matching_ratio(reference, predicted, score_threshold=0.25):
    scores = {}
    n = len(reference)
    for id1, c1 in enumerate(reference):
        for id2, c2 in enumerate(predicted):
            score = matching_score(c1, c2)
            if score <= score_threshold:
                continue
            scores[id1, id2+n] = score
    input = [(v1, v2, w) for (v1, v2), w in scores.iteritems()]
    mates = maxWeightMatching(input)
    score = sum(scores[i, mate] for i, mate in enumerate(mates) if i < mate)
    return score / n
###########################################################################
def positive_predictive_value(reference, predicted):
    num, den = 0., 0.
    for cluster in predicted:
        isects = [len(cluster.intersection(complex)) for complex in reference]
        isects.append(0.)
        num += max(isects)
        den += sum(isects)
    if den == 0.:
        return 0.
    return num / den
###########################################################################
def Jaccard_index(a,b):
    set_a = set(a)
    set_b = set(b)
    #print "set_a=",set_a
    #print "set_b=",set_b
    comm = float(len(set_a & set_b))
    #print "set_a & set_b=",set_a & set_b
    union = float(len(set_a | set_b))
    #print "union =",union
    return comm / union
###########################################################################
def Complex_wise_Jaccard_index(reference,predicted):
    top_score = 0.0
    down_score = 0.0
    for id in reference:
        w = 0.0
        Max_Jaccard_score = 0.0
        for it in predicted:
            w = Jaccard_index(reference[id],predicted[it])
            if w > Max_Jaccard_score:
                Max_Jaccard_score = w
            else:
                continue
        top_score = top_score + Max_Jaccard_score * len(reference[id])
        down_score = down_score +len(reference[id])
    return top_score/down_score
###########################################################################
def Cluster_wise_Jaccard_index(reference,predicted):
    top_score = 0.0
    down_score = 0.0
    for id in predicted:
        w = 0.0
        Max_Jaccard_score = 0.0
        for it in reference:
            w = Jaccard_index(reference[it],predicted[id])
            if w > Max_Jaccard_score:
                Max_Jaccard_score = w
            else:
                continue
        top_score = top_score + Max_Jaccard_score * len(predicted[id])
        down_score = down_score + len(predicted[id])
    return top_score/down_score
###########################################################################
def Jaccard_Fmeasure(reference_complexes1,predicted_complexes1):
    Complex_wise_Jaccard_indexs = Complex_wise_Jaccard_index(reference_complexes1,predicted_complexes1)
    #print "recall=",recall
    Cluster_wise_Jaccard_indexs = Cluster_wise_Jaccard_index(reference_complexes1,predicted_complexes1)
    #print "precision=",precision
    Jaccard_Fmeasures = (2*Complex_wise_Jaccard_indexs*Cluster_wise_Jaccard_indexs) / (Cluster_wise_Jaccard_indexs + Complex_wise_Jaccard_indexs)
    #print "F-measure=",f_measure
    return Jaccard_Fmeasures,Complex_wise_Jaccard_indexs,Cluster_wise_Jaccard_indexs
###########################################################################
def Common_proteins(a,b):
    set_a = set(a)
    set_b = set(b)
    #print "set_a=",set_a
    #print "set_b=",set_b
    comm = float(len(set_a & set_b))
    return comm
###########################################################################
def complex_wise_homogeneity(reference,predicted):
    HM = 0.0
    Sum_n = {}
    for ir in reference:
        sum_ir = 0.0
        for ip in predicted:
            sum_ir = sum_ir + Common_proteins(reference[ir],predicted[ip])
        Sum_n[ir] = sum_ir
    Sum_m = {}
    for ip1 in predicted:
        sum_ip = 0.0
        for ir1 in reference:
            sum_ip = sum_ip + Common_proteins(reference[ir1], predicted[ip1])
        Sum_m[ip1] = sum_ip
    sum_reference = 0.0
    for i in reference:
        sum = 0.0
        for j in predicted:
            w = Common_proteins(reference[i],predicted[j])
            print(Sum_m[j],Sum_n[i])
            sum = sum + (w / Sum_n[i]) * (w / Sum_m[j])
        sum_reference = sum + sum_reference
    HM = sum_reference/len(reference)
    return HM
###########################################################################
def clustering_wise_homogeneity(reference,predicted):
    HC = 0.0
    Sum_n = {}
    for ir in reference:
        sum_ir = 0.0
        for ip in predicted:
            sum_ir = sum_ir + Common_proteins(reference[ir],predicted[ip])
        Sum_n[ir] = sum_ir
    Sum_m = {}
    for ip1 in predicted:
        sum_ip = 0.0
        for ir1 in reference:
            sum_ip = sum_ip + Common_proteins(reference[ir1], predicted[ip1])
        Sum_m[ip1] = sum_ip
    sum_reference = 0.0
    for i in predicted:
        sum = 0.0
        for j in reference:
            w = Common_proteins(reference[j],predicted[i])
            sum = sum + (w / Sum_n[j]) * (w / Sum_m[i])
        sum_reference = sum + sum_reference
    HC = sum_reference/len(predicted)
    return HC
###########################################################################
def HG(reference_complexes1,predicted_complexes1):
    complex_wise_homogeneitys = complex_wise_homogeneity(reference_complexes1,predicted_complexes1)
    #print "recall=",recall
    clustering_wise_homogeneitys = clustering_wise_homogeneity(reference_complexes1,predicted_complexes1)
    #print "precision=",precision
    HGs = (2*complex_wise_homogeneitys*clustering_wise_homogeneitys) / (clustering_wise_homogeneitys + complex_wise_homogeneitys)
    #print "F-measure=",f_measure
    return HGs,complex_wise_homogeneitys,clustering_wise_homogeneitys
###########################################################################
def canonical_protein_name(name):
    """Returns the canonical name of a protein by performing a few simple
    transformations on the name."""
    return name.strip().upper()
###########################################################################
def is_numeric(x):
    """Returns whether the given string can be interpreted as a number."""
    try:
        float(x)
        return True
    except:
        return False
###########################################################################
def read_complexes(fname, known_proteins=None, strictness=0.5,min_size=3, max_size=1000):
        result = []
        for line in open(fname):
            ps = set(canonical_protein_name(x) for x in line.strip().split() if x)
            if known_proteins is not None:
                isect = ps.intersection(known_proteins)
                if len(isect) < max(min_size, len(ps) * strictness):
                    continue
                if len(isect) > max_size:
                    continue
                ps = isect
            result.append(ps)

        to_delete = set()
        for idx, cluster in enumerate(result):
            for idx2, cluster2 in enumerate(result):
                if idx == idx2 or idx2 in to_delete:
                    continue
                if cluster == cluster2:
                    to_delete.add(idx2)

        result = [r for i, r in enumerate(result) if i not in to_delete]
        return result
###########################################################################
def read_complexesp(fname):
    result = []
    for line in open(fname):
        line_1 = line.split()
        complexes = set(line_1[1:])
        # print("line=",complexes)
        result.append(complexes)

    to_delete = set()
    for idx, cluster in enumerate(result):
        for idx2, cluster2 in enumerate(result):
            if idx == idx2 or idx2 in to_delete:
                continue
            if cluster == cluster2:
                to_delete.add(idx2)

    result = [r for i, r in enumerate(result) if i not in to_delete]
    return result
###########################################################################
def read_network(fname):
        known_proteins = set()
        for line in open(fname):
            parts = [canonical_protein_name(part) for part in line.strip().split()
                    if not is_numeric(part)]
            known_proteins.update(parts)
        return known_proteins
###########################################################################

def main():
    dataset = 'Collins'
    dataset = 'Gavin'
    dataset = 'Krogan'
    print ("dataset=",dataset)
    ##1##############################################################
    filename = '..\datasets/' + dataset + '.txt'
    #################################################################
    #predicted_complexes = '..\Results/MP-AHSA_'+dataset+'0.44.1.36.txt'
    predicted_complexes = '..\Results\MP-AHSA_KroganW0.54.1.57.0.7.txt'
    name = 'PC2P_Krogan'
    #predicted_complexes = 'C:\Users\WRQ-PC\Desktop\manuscripts\Briefing in bioinformatics\compared algorithms/'+name+'.txt'
    ################################################################
    reference_complexes = '.\datasets/standardcomplexes1.txt'
    ################################################################
    predicted_complexes1 = read_complex1(predicted_complexes)
    #print "predicted_complexes1=", predicted_complexes1
    predicted_complexes1 = strtolist(predicted_complexes1)
    #print "predicted_complexes1=", predicted_complexes1
    predicted_complexes1 = refilter_complex(predicted_complexes1)
    #print "predicted_complexes1=", predicted_complexes1
    ################################################################
    reference_complexes1 = read_complex1(reference_complexes)
    reference_complexes1 = strtolist(reference_complexes1)
    reference_complexes1 = refilter_complex(reference_complexes1)
    ###############################################################
    known_proteins = read_network(filename)
    reference_complexes_N = read_complexes(reference_complexes,known_proteins)
    print ("reference_complexes_N =",reference_complexes_N)
    predicted_complexes_N = read_complexesp(predicted_complexes)
    print ("predicted_complexes_N=",predicted_complexes_N)
    ################################################################
    a = 0.20
    f_measure, recall, precision,averagesize =F_measure(reference_complexes1, predicted_complexes1,a)
    CR = Coverage(reference_complexes1, predicted_complexes1)
    #print "************************************************"
    cws = clusteringwise_sensitivity(reference_complexes_N, predicted_complexes_N)
    ppv = positive_predictive_value(reference_complexes_N, predicted_complexes_N)
    acc = accuracy(reference_complexes_N, predicted_complexes_N)
    #print "acc"
    #print "************************************************"
    mmr = maximum_matching_ratio(reference_complexes_N, predicted_complexes_N, score_threshold=0.2)
    sep = clusteringwise_separation(reference_complexes_N, predicted_complexes_N)
    frac = fraction_matched(reference_complexes_N,predicted_complexes_N, score_threshold=0.25)
    #print "************************************************"
    Jaccard_Fmeasures, Complex_wise_Jaccard_indexs, Cluster_wise_Jaccard_indexs = Jaccard_Fmeasure(
        reference_complexes1, predicted_complexes1)
    print (len(predicted_complexes1))
    print (averagesize)
    print (f_measure)
    #print (CR)
    print (acc)
    print (mmr)
    #print (sep)
    print (frac)
    print (Jaccard_Fmeasures)
    #print f_measure + CR + acc + mmr + frac + Jaccard_Fmeasures
    print (name + "&" + str(len(predicted_complexes1)) + "&"+ str(round(averagesize,2))+ "&" + str(round(f_measure, 4))+ "&" + str(round(acc, 4)) + "&" + str(round(mmr, 4)) + "&" + str(round(frac, 4)) + "&" + str(round(Jaccard_Fmeasures, 4)) + "&" + str(round(f_measure + acc + mmr + frac + Jaccard_Fmeasures, 4)) + "\\" + "\\")
    print ("======================================")
main()